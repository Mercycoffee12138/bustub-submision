//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree.h
//
// Identification: src/include/storage/index/b_plus_tree.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

/**
 * b_plus_tree.h
 *
 * Implementation of simple b+ tree data structure where internal pages direct
 * the search and leaf pages contain actual data.
 * (1) We only support unique key
 * (2) support insert & remove
 * (3) The structure should shrink and grow dynamically
 * (4) Implement index iterator for range scan
 */
 #pragma once

 #include <algorithm>
 #include <deque>
 #include <filesystem>
 #include <iostream>
 #include <optional>
 #include <queue>
 #include <shared_mutex>
 #include <string>
 #include <vector>
 #include <unordered_set>
 #include <functional> 
 
 #include "common/config.h"
 #include "common/macros.h"
 #include "storage/index/index_iterator.h"
 #include "storage/page/b_plus_tree_header_page.h"
 #include "storage/page/b_plus_tree_internal_page.h"
 #include "storage/page/b_plus_tree_leaf_page.h"
 #include "storage/page/page_guard.h"
 
 namespace bustub {
 
 struct PrintableBPlusTree;
 
 /**
  * @brief Definition of the Context class.
  *
  * Hint: This class is designed to help you keep track of the pages
  * that you're modifying or accessing.
  */
 class Context {
  public:

  // 添加析构函数
  ~Context() {
    // 清空读集合和写集合
    read_set_.clear();
    write_set_.clear();
    // 释放头页面
    header_page_ = std::nullopt;
  }

   // When you insert into / remove from the B+ tree, store the write guard of header page here.
   // Remember to drop the header page guard and set it to nullopt when you want to unlock all.
   std::optional<WritePageGuard> header_page_{std::nullopt};
 
   // Save the root page id here so that it's easier to know if the current page is the root page.
   page_id_t root_page_id_{INVALID_PAGE_ID};
 
   // Store the write guards of the pages that you're modifying here.
   std::deque<WritePageGuard> write_set_;
 
   // You may want to use this when getting value, but not necessary.
   std::deque<ReadPageGuard> read_set_;
 
   auto IsRootPage(page_id_t page_id) -> bool { return page_id == root_page_id_; }
 };
 
 #define BPLUSTREE_TYPE BPlusTree<KeyType, ValueType, KeyComparator>
 
 // Main class providing the API for the Interactive B+ Tree.
 INDEX_TEMPLATE_ARGUMENTS
 class BPlusTree {
   using InternalPage = BPlusTreeInternalPage<KeyType, page_id_t, KeyComparator>;
   using LeafPage = BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>;
 
  public:
   explicit BPlusTree(std::string name, page_id_t header_page_id, BufferPoolManager *buffer_pool_manager,
                      const KeyComparator &comparator, int leaf_max_size = LEAF_PAGE_SLOT_CNT,
                      int internal_max_size = INTERNAL_PAGE_SLOT_CNT);
 
   // Returns true if this B+ tree has no keys and values.
   auto IsEmpty() const -> bool;
    
   auto GetLeafPage(const KeyType &key, Context &ctx) ->const LeafPage*;
   // Insert a key-value pair into this B+ tree.
   auto Insert(const KeyType &key, const ValueType &value) -> bool;

   auto InsertIntoLeaf(const KeyType &key, const ValueType &value, Context *ctx) -> bool;

   auto CreateNewRoot(const KeyType &key, const ValueType &value, Context *ctx) -> bool ;

   auto InsertIntoLeafInternal(LeafPage *leaf_page, const KeyType &key, const ValueType &value, Context *ctx) -> bool;

   auto InsertIntoParent(BPlusTreePage *left_page, const KeyType &key, BPlusTreePage *right_page, Context *ctx) -> bool;
 
   // Remove a key and its value from this B+ tree.
   void Remove(const KeyType &key);

   auto FindAndRemoveFromLeaf(const KeyType &key, Context *ctx) -> bool;

   auto AdjustAfterRemove(Context *ctx) -> bool;
 
   // Return the value associated with a given key
   auto FindLeafPage(Context &ctx, const KeyType &key, const std::string &operation) -> bool;

   auto GetValue(const KeyType &key, std::vector<ValueType> *result) -> bool;
 
   // Return the page id of the root node
   auto GetRootPageId() -> page_id_t;
 
   // Index iterator
   auto Begin() -> INDEXITERATOR_TYPE;
 
   auto End() -> INDEXITERATOR_TYPE;
 
   auto Begin(const KeyType &key) -> INDEXITERATOR_TYPE;
 
   void Print(BufferPoolManager *bpm);
 
   void Draw(BufferPoolManager *bpm, const std::filesystem::path &outf);
 
   auto DrawBPlusTree() -> std::string;
 
   // read data from file and insert one by one
   void InsertFromFile(const std::filesystem::path &file_name);
 
   // read data from file and remove one by one
   void RemoveFromFile(const std::filesystem::path &file_name);
 
   void BatchOpsFromFile(const std::filesystem::path &file_name);
 
  private:
   void ToGraph(page_id_t page_id, const BPlusTreePage *page, std::ofstream &out);
 
   void PrintTree(page_id_t page_id, const BPlusTreePage *page);
 
   auto ToPrintableBPlusTree(page_id_t root_id) -> PrintableBPlusTree;

  // std::mutex recent_keys_mutex_;
  // std::unordered_set<std::string> recent_inserted_keys_;
  static std::mutex global_insert_mutex_;
  static std::mutex global_remove_mutex_;
  static std::mutex global_tree_mutex_;
 
   // member variable
   std::string index_name_;
   BufferPoolManager *bpm_;
   KeyComparator comparator_;
   std::vector<std::string> log;  // NOLINT
   int leaf_max_size_;
   int internal_max_size_;
   page_id_t header_page_id_;
 };
 
 /**
  * @brief for test only. PrintableBPlusTree is a printable B+ tree.
  * We first convert B+ tree into a printable B+ tree and the print it.
  */
 struct PrintableBPlusTree {
   int size_;
   std::string keys_;
   std::vector<PrintableBPlusTree> children_;
 
   /**
    * @brief BFS traverse a printable B+ tree and print it into
    * into out_buf
    *
    * @param out_buf
    */
   void Print(std::ostream &out_buf) {
     std::vector<PrintableBPlusTree *> que = {this};
     while (!que.empty()) {
       std::vector<PrintableBPlusTree *> new_que;
 
       for (auto &t : que) {
         int padding = (t->size_ - t->keys_.size()) / 2;
         out_buf << std::string(padding, ' ');
         out_buf << t->keys_;
         out_buf << std::string(padding, ' ');
 
         for (auto &c : t->children_) {
           new_que.push_back(&c);
         }
       }
       out_buf << "\n";
       que = new_que;
     }
   }
 };
}  // namespace bustub