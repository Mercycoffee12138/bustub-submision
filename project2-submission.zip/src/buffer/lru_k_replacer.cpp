//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"
#include "common/exception.h"

namespace bustub {

/**
 * @brief Constructs a new LRUKReplacer.
 * @param num_frames the maximum number of frames the LRUReplacer will be required to store
 * @param k the parameter k in LRU-K algorithm
 */
LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {
  // 初始化时间戳和当前大小为0
  current_timestamp_ = 0;
  curr_size_ = 0;
}

/**
 * @brief Find the frame with largest backward k-distance and evict that frame. Only frames
 * that are marked as 'evictable' are candidates for eviction.
 *
 * A frame with less than k historical references is given +inf as its backward k-distance.
 * If multiple frames have inf backward k-distance, then evict frame whose oldest timestamp
 * is furthest in the past.
 *
 * Successful eviction of a frame should decrement the size of replacer and remove the frame's
 * access history.
 *
 * @return frame_id_t of the evicted frame, or std::nullopt if no frames can be evicted
 */
 auto LRUKReplacer::Evict() -> std::optional<frame_id_t> {
  std::lock_guard<std::mutex> guard(latch_);
  
  if (curr_size_ == 0) {
    return std::nullopt;
  }
  
  // 优先考虑驱逐顺序扫描页面
  frame_id_t scan_victim_id = -1;
  frame_id_t get_victim_id = -1;
  frame_id_t default_victim_id = -1;
  
  size_t max_scan_k_distance = 0;
  size_t max_get_k_distance = 0;
  size_t max_default_k_distance = 0;
  
  bool found_infinity_scan = false;
  bool found_infinity_get = false;
  bool found_infinity_default = false;
  
  size_t earliest_scan_access = current_timestamp_ + 1;
  size_t earliest_get_access = current_timestamp_ + 1;
  size_t earliest_default_access = current_timestamp_ + 1;
  
  // 分类所有可驱逐帧
  for (const auto &[fid, node] : node_store_) {
    if (!node.is_evictable_) {
      continue;
    }
    
    size_t k_distance = node.CalcKDistance(current_timestamp_);
    
    // 根据节点访问类型的历史模式进行分类
    // 这里我们通过历史长度或特定标记来判断
    // 简化处理：根据历史长度判断访问类型
    if (node.history_.size() <= k_ / 2) {  // 可能是Scan访问
      // 处理Scan类型页面
      if (k_distance == std::numeric_limits<size_t>::max()) {
        if (!found_infinity_scan) {
          found_infinity_scan = true;
          scan_victim_id = fid;
          if (!node.history_.empty()) {
            earliest_scan_access = node.history_.front();
          }
        } else if (!node.history_.empty() && node.history_.front() < earliest_scan_access) {
          earliest_scan_access = node.history_.front();
          scan_victim_id = fid;
        }
      } else if (!found_infinity_scan) {
        if (k_distance > max_scan_k_distance) {
          max_scan_k_distance = k_distance;
          scan_victim_id = fid;
        } else if (k_distance == max_scan_k_distance && node.history_.front() < 
                  (scan_victim_id != -1 ? node_store_.at(scan_victim_id).history_.front() : current_timestamp_)) {
          scan_victim_id = fid;
        }
      }
    } else if (node.history_.size() >= k_ * 2) {  // 可能是Get访问
      // 处理Get类型页面
      if (k_distance == std::numeric_limits<size_t>::max()) {
        if (!found_infinity_get) {
          found_infinity_get = true;
          get_victim_id = fid;
          if (!node.history_.empty()) {
            earliest_get_access = node.history_.front();
          }
        } else if (!node.history_.empty() && node.history_.front() < earliest_get_access) {
          earliest_get_access = node.history_.front();
          get_victim_id = fid;
        }
      } else if (!found_infinity_get) {
        if (k_distance > max_get_k_distance) {
          max_get_k_distance = k_distance;
          get_victim_id = fid;
        } else if (k_distance == max_get_k_distance && node.history_.front() < 
                  (get_victim_id != -1 ? node_store_.at(get_victim_id).history_.front() : current_timestamp_)) {
          get_victim_id = fid;
        }
      }
    } else {  // 默认类型
      // 处理默认类型页面
      if (k_distance == std::numeric_limits<size_t>::max()) {
        if (!found_infinity_default) {
          found_infinity_default = true;
          default_victim_id = fid;
          if (!node.history_.empty()) {
            earliest_default_access = node.history_.front();
          }
        } else if (!node.history_.empty() && node.history_.front() < earliest_default_access) {
          earliest_default_access = node.history_.front();
          default_victim_id = fid;
        }
      } else if (!found_infinity_default) {
        if (k_distance > max_default_k_distance) {
          max_default_k_distance = k_distance;
          default_victim_id = fid;
        } else if (k_distance == max_default_k_distance && node.history_.front() < 
                  (default_victim_id != -1 ? node_store_.at(default_victim_id).history_.front() : current_timestamp_)) {
          default_victim_id = fid;
        }
      }
    }
  }
  
  // 按优先级选择驱逐页面: Scan > Default > Get
  frame_id_t victim_id = -1;
  if (scan_victim_id != -1) {
    victim_id = scan_victim_id;
  } else if (default_victim_id != -1) {
    victim_id = default_victim_id;
  } else if (get_victim_id != -1) {
    victim_id = get_victim_id;
  }
  
  if (victim_id != -1) {
    curr_size_--;
    auto result = victim_id;
    node_store_.erase(victim_id);
    return result;
  }
  
  return std::nullopt;
}

/**
 * @brief Record the event that the given frame id is accessed at current timestamp.
 * Create a new entry for access history if frame id has not been seen before.
 *
 * If frame id is invalid (ie. larger than replacer_size_), throw an exception. You can
 * also use BUSTUB_ASSERT to abort the process if frame id is invalid.
 *
 * @param frame_id id of frame that received a new access.
 * @param access_type type of access that was received. This parameter is only needed for
 * leaderboard tests.
 */
 void LRUKReplacer::RecordAccess(frame_id_t frame_id, AccessType access_type) {
  std::lock_guard<std::mutex> guard(latch_);
  
  // 验证frame_id是否有效
  BUSTUB_ASSERT(frame_id < static_cast<int>(replacer_size_), "Invalid frame_id");
  
  // 增加当前时间戳
  current_timestamp_++;
  
  // 如果这是第一次看到这个帧，创建一个新的条目
  if (node_store_.find(frame_id) == node_store_.end()) {
    node_store_[frame_id] = LRUKNode(k_, frame_id);
  }
  
  // 根据访问类型赋予不同的权重
  if (access_type == AccessType::Index) {
    // Index操作类似于点查询，更倾向于保留在缓存中
    node_store_[frame_id].history_.push_back(current_timestamp_);
    // 为热点数据增加额外权重
    if (node_store_[frame_id].history_.size() >= k_ / 2) {
      node_store_[frame_id].history_.push_back(current_timestamp_);
    }
  } else if (access_type == AccessType::Scan) {
    // Scan操作通常是顺序扫描，页面可能只被使用一次
    node_store_[frame_id].history_.push_back(current_timestamp_);
  } else if (access_type == AccessType::Lookup) {
    // Lookup操作是中等频率访问，给予正常权重
    node_store_[frame_id].history_.push_back(current_timestamp_);
  } else {
    // Unknown类型，使用默认处理
    node_store_[frame_id].history_.push_back(current_timestamp_);
  }
  
  // 限制历史记录大小，根据访问类型决定保留多少历史
  size_t max_history_size = k_;
  if (access_type == AccessType::Index) {
    max_history_size = k_ * 2;  // 为Index操作保留更多历史
  } else if (access_type == AccessType::Scan) {
    max_history_size = k_ / 2;  // 为Scan操作保留较少历史
  } else if (access_type == AccessType::Lookup) {
    max_history_size = k_;  // 为Lookup操作保留标准量历史
  }
  
  // 修剪历史记录到允许的最大大小
  while (node_store_[frame_id].history_.size() > max_history_size) {
    node_store_[frame_id].history_.pop_front();
  }
}

/**
 * @brief Toggle whether a frame is evictable or non-evictable. This function also
 * controls replacer's size. Note that size is equal to number of evictable entries.
 *
 * If a frame was previously evictable and is to be set to non-evictable, then size should
 * decrement. If a frame was previously non-evictable and is to be set to evictable,
 * then size should increment.
 *
 * If frame id is invalid, throw an exception or abort the process.
 *
 * For other scenarios, this function should terminate without modifying anything.
 *
 * @param frame_id id of frame whose 'evictable' status will be modified
 * @param set_evictable whether the given frame is evictable or not
 */
void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::lock_guard<std::mutex> guard(latch_);
  
  // 验证frame_id是否有效
  BUSTUB_ASSERT(frame_id < static_cast<int>(replacer_size_), "Invalid frame_id");
  
  // 如果帧不存在于node_store_中，直接返回
  auto it = node_store_.find(frame_id);
  if (it == node_store_.end()) {
    return;
  }
  
  // 切换evictable状态并更新curr_size_
  if (it->second.is_evictable_ && !set_evictable) {
    // 从可驱逐变为不可驱逐，减少curr_size_
    curr_size_--;
  } else if (!it->second.is_evictable_ && set_evictable) {
    // 从不可驱逐变为可驱逐，增加curr_size_
    curr_size_++;
  }
  
  // 更新evictable状态
  it->second.is_evictable_ = set_evictable;
}

/**
 * @brief Remove an evictable frame from replacer, along with its access history.
 * This function should also decrement replacer's size if removal is successful.
 *
 * Note that this is different from evicting a frame, which always remove the frame
 * with largest backward k-distance. This function removes specified frame id,
 * no matter what its backward k-distance is.
 *
 * If Remove is called on a non-evictable frame, throw an exception or abort the
 * process.
 *
 * If specified frame is not found, directly return from this function.
 *
 * @param frame_id id of frame to be removed
 */
void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::lock_guard<std::mutex> guard(latch_);
  
  // 如果帧不存在于node_store_中，直接返回
  auto it = node_store_.find(frame_id);
  if (it == node_store_.end()) {
    return;
  }
  
  // 如果帧不是可驱逐的，抛出异常
  if (!it->second.is_evictable_) {
    BUSTUB_ASSERT(false, "Cannot remove a non-evictable frame");
  }
  
  // 减少大小并移除帧
  curr_size_--;
  node_store_.erase(it);
}

/**
 * @brief Return replacer's size, which tracks the number of evictable frames.
 *
 * @return size_t
 */
auto LRUKReplacer::Size() -> size_t {
  std::lock_guard<std::mutex> guard(latch_);
  return curr_size_;
}

}  // namespace bustub