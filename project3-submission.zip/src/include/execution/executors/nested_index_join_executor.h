//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nested_index_join_executor.h
//
// Identification: src/include/execution/executors/nested_index_join_executor.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#include "type/value_factory.h" 

#include "execution/executor_context.h"
#include "execution/executors/abstract_executor.h"
#include "execution/expressions/abstract_expression.h"
#include "execution/plans/nested_index_join_plan.h"
#include "storage/table/tmp_tuple.h"
#include "storage/table/tuple.h"

namespace bustub {

/**
 * IndexJoinExecutor executes index join operations.
 */
class NestIndexJoinExecutor : public AbstractExecutor {
 public:
  NestIndexJoinExecutor(ExecutorContext *exec_ctx, const NestedIndexJoinPlanNode *plan,
                        std::unique_ptr<AbstractExecutor> &&child_executor);

  auto GetOutputSchema() const -> const Schema & override { return plan_->OutputSchema(); }

  void Init() override;

  auto Next(Tuple *tuple, RID *rid) -> bool override;

  Tuple ConstructProbeKey(const Tuple *outer_tuple);

 private:
  /** The nested index join plan node. */
  const NestedIndexJoinPlanNode *plan_;
  /** The child executor for outer table. */
  std::unique_ptr<AbstractExecutor> child_executor_;
  /** Index info. */
  std::shared_ptr<IndexInfo> index_info_;
  /** Table info. */
  std::shared_ptr<TableInfo> table_info_;
  /** Current outer tuple being processed. */
  Tuple outer_tuple_;
  /** RID of the current outer tuple. */
  RID outer_rid_;

  std::vector<RID> inner_rids_;
  /** Inner tuples matching the current outer tuple. */
  std::vector<std::pair<RID, Tuple>> inner_tuples_;
  /** Index of the current inner tuple. */
  size_t inner_tuple_idx_;
  /** Flag indicating if all tuples have been processed. */
  bool is_end_;
  /** Flag indicating if the current outer tuple has a match (for LEFT JOIN). */
  bool left_has_match_;
  /** Helper function to construct probe key for index lookup. */
};
}  // namespace bustub
