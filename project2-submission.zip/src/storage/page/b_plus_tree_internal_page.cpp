//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree_internal_page.cpp
//
// Identification: src/storage/page/b_plus_tree_internal_page.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <iostream>
#include <sstream>

#include "common/exception.h"
#include "storage/page/b_plus_tree_internal_page.h"

namespace bustub {
/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/

/**
 * @brief Init method after creating a new internal page.
 *
 * Writes the necessary header information to a newly created page,
 * including set page type, set current size, set page id, set parent id and set max page size,
 * must be called after the creation of a new page to make a valid BPlusTreeInternalPage.
 *
 * @param max_size Maximal size of the page
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::Init(int max_size) { 
  // 设置页面类型为内部页面
  SetPageType(IndexPageType::INTERNAL_PAGE);
  // 初始时，页面大小为1，因为有一个无效的key和一个有效的指针
  SetSize(1);
  // 设置最大页面大小
  SetMaxSize(max_size);
 }

/**
 * @brief Helper method to get/set the key associated with input "index"(a.k.a
 * array offset).
 *
 * @param index The index of the key to get. Index must be non-zero.
 * @return Key at index
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::KeyAt(int index) const -> KeyType {
  return key_array_[index];
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::KeyIndex(const KeyType &key, const KeyComparator &comparator) const -> int {
  // 注意：内部节点的键从索引1开始，索引0的值没有对应的键
  // 二分查找找到第一个大于等于key的键
  int left = 1;  // 从1开始，因为内部节点的第一个键是从索引1开始的
  int right = GetSize() - 1;
  // 如果所有键都比目标键小，直接返回size
  if (right > 0 && comparator(KeyAt(right), key) < 0) {
    return GetSize();
  }
    // 二分查找
  while (left <= right) {
    int mid = left + (right - left) / 2;
    int cmp = comparator(KeyAt(mid), key);
    
    if (cmp == 0) {
      return mid;  // 找到精确匹配
    } else if (cmp < 0) {
      left = mid + 1;  // 在右侧继续查找
    } else {
      right = mid - 1;  // 在左侧继续查找
    }
  }
  
  // 返回第一个大于等于key的位置
  return left;
}

/**
 * @brief Set key at the specified index.
 *
 * @param index The index of the key to set. Index must be non-zero.
 * @param key The new value for key
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::SetKeyAt(int index, const KeyType &key) {
   // 确保索引不为零（第一个key是无效的）
  assert(index >= 1);
  key_array_[index] = key;
}
//自填加索引函数
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::ValueIndex(const ValueType &value) const -> int {
  for (int i = 0; i < GetSize(); i++) {
    if (page_id_array_[i] == value) {
      return i;
    }
  }
  return -1;  // 如果找不到该value，返回-1
}
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::SetValueAt(int index, const ValueType &value) {
  assert(index >= 0);
  page_id_array_[index] = value;
}
/**
 * @brief Helper method to get the value associated with input "index"(a.k.a array
 * offset)
 *
 * @param index The index of the value to get.
 * @return Value at index
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::ValueAt(int index) const -> ValueType {
  assert(index >= 0 && index < GetSize());
  return page_id_array_[index];
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::PopulateNewRoot(const page_id_t left_child, const KeyType &key, 
                                                    const page_id_t right_child) {
  // 清空当前节点内容
  SetSize(0);
  // 设置第一个值指向左子节点
  page_id_array_[0] = left_child;  // 使用page_id_array_而不是array_
  // 设置第一个键
  key_array_[1] = key;  // 使用key_array_而不是array_[1].first
  // 设置第二个值指向右子节点
  page_id_array_[1] = right_child;  // 使用page_id_array_而不是array_[1].second
  // 内部节点初始大小为2（存储了1个键和2个子节点指针）
  SetSize(2);
}

INDEX_TEMPLATE_ARGUMENTS
bool B_PLUS_TREE_INTERNAL_PAGE_TYPE::InsertNodeAfter(const ValueType &old_value, const KeyType &new_key, 
                                                    const ValueType &new_value) {
  // 如果页面已满，不能插入更多元素
  if (GetSize() >= GetMaxSize()) {
    return false;
  }
  // 查找old_value所在的索引位置
  int old_index = ValueIndex(old_value);
  if (old_index == -1) {
    // 如果找不到old_value，插入失败
    return false;
  }
  // 将old_index之后的所有键值对向后移动一位
  for (int i = GetSize(); i > old_index + 1; i--) {
    // 移动键
    SetKeyAt(i, KeyAt(i - 1));
    // 移动值（子节点指针）
    page_id_array_[i] = page_id_array_[i - 1];
  }
  // 在old_index之后插入新的键值对
  SetKeyAt(old_index + 1, new_key);
  page_id_array_[old_index + 1] = new_value;
  // 增加节点大小
  SetSize(GetSize() + 1);
  return true;
}

// valuetype for internalNode should be page id_t
template class BPlusTreeInternalPage<GenericKey<4>, page_id_t, GenericComparator<4>>;
template class BPlusTreeInternalPage<GenericKey<8>, page_id_t, GenericComparator<8>>;
template class BPlusTreeInternalPage<GenericKey<16>, page_id_t, GenericComparator<16>>;
template class BPlusTreeInternalPage<GenericKey<32>, page_id_t, GenericComparator<32>>;
template class BPlusTreeInternalPage<GenericKey<64>, page_id_t, GenericComparator<64>>;
}  // namespace bustub