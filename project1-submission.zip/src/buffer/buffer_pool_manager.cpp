//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager.cpp
//
// Identification: src/buffer/buffer_pool_manager.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/buffer_pool_manager.h"

namespace bustub {

/**
 * @brief The constructor for a `FrameHeader` that initializes all fields to default values.
 *
 * See the documentation for `FrameHeader` in "buffer/buffer_pool_manager.h" for more information.
 *
 * @param frame_id The frame ID / index of the frame we are creating a header for.
 */
FrameHeader::FrameHeader(frame_id_t frame_id) : frame_id_(frame_id), data_(BUSTUB_PAGE_SIZE, 0) { Reset(); }

/**
 * @brief Get a raw const pointer to the frame's data.
 *
 * @return const char* A pointer to immutable data that the frame stores.
 */
auto FrameHeader::GetData() const -> const char * { return data_.data(); }

/**
 * @brief Get a raw mutable pointer to the frame's data.
 *
 * @return char* A pointer to mutable data that the frame stores.
 */
auto FrameHeader::GetDataMut() -> char * { return data_.data(); }

/**
 * @brief Resets a `FrameHeader`'s member fields.
 */
void FrameHeader::Reset() {
  std::fill(data_.begin(), data_.end(), 0);
  pin_count_.store(0);
  is_dirty_ = false;
}

/**
 * @brief Creates a new `BufferPoolManager` instance and initializes all fields.
 *
 * See the documentation for `BufferPoolManager` in "buffer/buffer_pool_manager.h" for more information.
 *
 * ### Implementation
 *
 * We have implemented the constructor for you in a way that makes sense with our reference solution. You are free to
 * change anything you would like here if it doesn't fit with you implementation.
 *
 * Be warned, though! If you stray too far away from our guidance, it will be much harder for us to help you. Our
 * recommendation would be to first implement the buffer pool manager using the stepping stones we have provided.
 *
 * Once you have a fully working solution (all Gradescope test cases pass), then you can try more interesting things!
 *
 * @param num_frames The size of the buffer pool.
 * @param disk_manager The disk manager.
 * @param k_dist The backward k-distance for the LRU-K replacer.
 * @param log_manager The log manager. Please ignore this for P1.
 */
BufferPoolManager::BufferPoolManager(size_t num_frames, DiskManager *disk_manager, size_t k_dist,
                                     LogManager *log_manager)
    : num_frames_(num_frames),
      next_page_id_(0),
      bpm_latch_(std::make_shared<std::mutex>()),
      replacer_(std::make_shared<LRUKReplacer>(num_frames, k_dist)),
      disk_scheduler_(std::make_shared<DiskScheduler>(disk_manager)),
      log_manager_(log_manager) {
  // Not strictly necessary...
  std::scoped_lock latch(*bpm_latch_);
  next_page_id_.store(0);
  frames_.reserve(num_frames_);
  page_table_.reserve(num_frames_);
  for (size_t i = 0; i < num_frames_; i++) {
    frames_.push_back(std::make_shared<FrameHeader>(i));
    free_frames_.push_back(static_cast<int>(i));
  }
}

/**
 * @brief Destroys the `BufferPoolManager`, freeing up all memory that the buffer pool was using.
 */
BufferPoolManager::~BufferPoolManager() = default;

/**
 * @brief Returns the number of frames that this buffer pool manages.
 */
auto BufferPoolManager::Size() const -> size_t { return num_frames_; }

/**
 * @brief Allocates a new page on disk.
 *
 * ### Implementation
 *
 * You will maintain a thread-safe, monotonically increasing counter in the form of a `std::atomic<page_id_t>`.
 * See the documentation on [atomics](https://en.cppreference.com/w/cpp/atomic/atomic) for more information.
 *
 * TODO(P1): Add implementation.
 *
 * @return The page ID of the newly allocated page.
 */
auto BufferPoolManager::NewPage() -> page_id_t { 
  std::lock_guard<std::mutex> guard(*bpm_latch_);
  // 1. 尝试获取一个空闲的帧
  frame_id_t frame_id;
  if (!free_frames_.empty())
  {
    // 有空闲帧可用
    frame_id = free_frames_.front();
    free_frames_.pop_front();
  } 
  else if (auto victim_id = replacer_->Evict()) 
  {
    // 需要驱逐一个页面以获取帧
    frame_id = *victim_id;
    // 如果被驱逐的帧是脏页，需要将其写回磁盘
    auto old_page_id = INVALID_PAGE_ID;
    // 找到被驱逐的帧对应的页ID
    for (const auto &[pid, fid] : page_table_) 
    {
      if (fid == frame_id) 
      {
        old_page_id = pid;
        break;
      }
    }
    
    if (old_page_id != INVALID_PAGE_ID) {
      // 如果是脏页，复制数据用于写回
      char* data_copy = nullptr;
      {
        // 仅在复制数据时短暂持有锁
        std::unique_lock<std::shared_mutex> victim_lock(frames_[frame_id]->rwlatch_);
        if (frames_[frame_id]->is_dirty_) {
          data_copy = new char[BUSTUB_PAGE_SIZE];
          std::memcpy(data_copy, frames_[frame_id]->GetData(), BUSTUB_PAGE_SIZE);
        }
        // 从页表中移除这个条目
        page_table_.erase(old_page_id);
        // 锁在这里自动释放
      }
      // 如果需要写回磁盘，在释放锁后执行
      if (data_copy != nullptr) {
        auto promise = disk_scheduler_->CreatePromise();
        auto future = promise.get_future();
        
        DiskRequest request;
        request.is_write_ = true;
        request.data_ = data_copy;
        request.page_id_ = old_page_id;
        request.callback_ = std::move(promise);
        
        disk_scheduler_->Schedule(std::move(request));
        future.get();  // 在锁释放后等待I/O完成
        
        delete[] data_copy;
      }
    }
    // 重置帧
    frames_[frame_id]->Reset();
  } 
  else 
  {
    // 无法找到可用帧
    return INVALID_PAGE_ID;
  }
   // 2. 获取一个新的页面ID
   page_id_t new_page_id = next_page_id_.fetch_add(1);
  
   // 重置帧
    frames_[frame_id]->Reset();

  // 初始化页面头部数据
    char* data = frames_[frame_id]->GetDataMut();
    memcpy(data, &new_page_id, sizeof(page_id_t));

   frames_[frame_id]->pin_count_.store(0);  // 直接设置为0，而不是增加
   
   // 5. 在替换器中记录访问并设为不可驱逐
   replacer_->RecordAccess(frame_id);
   replacer_->SetEvictable(frame_id, false);
   // 3. 更新页表
   page_table_[new_page_id] = frame_id;
   
   return new_page_id;
 }

/**
 * @brief Removes a page from the database, both on disk and in memory.
 *
 * If the page is pinned in the buffer pool, this function does nothing and returns `false`. Otherwise, this function
 * removes the page from both disk and memory (if it is still in the buffer pool), returning `true`.
 *
 * ### Implementation
 *
 * Think about all of the places a page or a page's metadata could be, and use that to guide you on implementing this
 * function. You will probably want to implement this function _after_ you have implemented `CheckedReadPage` and
 * `CheckedWritePage`.
 *
 * Ideally, we would want to ensure that all space on disk is used efficiently. That would mean the space that deleted
 * pages on disk used to occupy should somehow be made available to new pages allocated by `NewPage`.
 *
 * If you would like to attempt this, you are free to do so. However, for this implementation, you are allowed to
 * assume you will not run out of disk space and simply keep allocating disk space upwards in `NewPage`.
 *
 * For (nonexistent) style points, you can still call `DeallocatePage` in case you want to implement something slightly
 * more space-efficient in the future.
 *
 * TODO(P1): Add implementation.
 *
 * @param page_id The page ID of the page we want to delete.
 * @return `false` if the page exists but could not be deleted, `true` if the page didn't exist or deletion succeeded.
 */
auto BufferPoolManager::DeletePage(page_id_t page_id) -> bool { 
   // 无效的页ID
   if (page_id == INVALID_PAGE_ID) {
    return true;
  }
  std::lock_guard<std::mutex> guard(*bpm_latch_);
  // 检查页面是否在缓冲池中
  auto it = page_table_.find(page_id);
  if (it != page_table_.end()) 
  {
    // 页面在缓冲池中
    frame_id_t frame_id = it->second;
    auto frame = frames_[frame_id];
    // 如果页面仍然被引用(pin)，不能删除
    if (frame->pin_count_.load() > 0) {
      return false;
    }   
    // 页面不再被引用，可以删除
    // 从页表中移除
    page_table_.erase(it);    
    // 重置帧
    frame->Reset();
    // 从替换器中删除
    replacer_->Remove(frame_id);
    // 将帧加回空闲列表
    free_frames_.push_back(frame_id);
  }
  // 从磁盘中删除页面
  disk_scheduler_->DeallocatePage(page_id);
  return true;
}

/**
 * @brief Acquires an optional write-locked guard over a page of data. The user can specify an `AccessType` if needed.
 *
 * If it is not possible to bring the page of data into memory, this function will return a `std::nullopt`.
 *
 * Page data can _only_ be accessed via page guards. Users of this `BufferPoolManager` are expected to acquire either a
 * `ReadPageGuard` or a `WritePageGuard` depending on the mode in which they would like to access the data, which
 * ensures that any access of data is thread-safe.
 *
 * There can only be 1 `WritePageGuard` reading/writing a page at a time. This allows data access to be both immutable
 * and mutable, meaning the thread that owns the `WritePageGuard` is allowed to manipulate the page's data however they
 * want. If a user wants to have multiple threads reading the page at the same time, they must acquire a `ReadPageGuard`
 * with `CheckedReadPage` instead.
 *
 * ### Implementation
 *
 * There are 3 main cases that you will have to implement. The first two are relatively simple: one is when there is
 * plenty of available memory, and the other is when we don't actually need to perform any additional I/O. Think about
 * what exactly these two cases entail.
 *
 * The third case is the trickiest, and it is when we do not have any _easily_ available memory at our disposal. The
 * buffer pool is tasked with finding memory that it can use to bring in a page of memory, using the replacement
 * algorithm you implemented previously to find candidate frames for eviction.
 *
 * Once the buffer pool has identified a frame for eviction, several I/O operations may be necessary to bring in the
 * page of data we want into the frame.
 *
 * There is likely going to be a lot of shared code with `CheckedReadPage`, so you may find creating helper functions
 * useful.
 *
 * These two functions are the crux of this project, so we won't give you more hints than this. Good luck!
 *
 * TODO(P1): Add implementation.
 *
 * @param page_id The ID of the page we want to write to.
 * @param access_type The type of page access.
 * @return std::optional<WritePageGuard> An optional latch guard where if there are no more free frames (out of memory)
 * returns `std::nullopt`, otherwise returns a `WritePageGuard` ensuring exclusive and mutable access to a page's data.
 */
auto BufferPoolManager::CheckedWritePage(page_id_t page_id, AccessType access_type) -> std::optional<WritePageGuard> {
  if (page_id == INVALID_PAGE_ID) {
    return std::nullopt;
  }
  std::shared_ptr<FrameHeader> frame;
  frame_id_t frame_id;
  bool need_disk_read = false;
  page_id_t old_page_id = INVALID_PAGE_ID;  // 添加变量声明
   // 定义收集需要刷盘的页面的向量
   std::vector<std::pair<page_id_t, char*>> pages_to_flush;
  // 首先尝试查找页面并获取帧，短暂持有 bpm_latch_
  {
    std::lock_guard<std::mutex> guard(*bpm_latch_);
    auto it = page_table_.find(page_id);
    if (it != page_table_.end()) 
    {
      // 页面在缓冲池中
      frame_id = it->second;
      frame = frames_[frame_id];
      
      // 只有当这个不是一个新创建的页面时才增加pin计数
      frame->pin_count_.fetch_add(1);
      // 记录访问
      replacer_->RecordAccess(frame_id, access_type);
      replacer_->SetEvictable(frame_id, false);
    } 
    else 
    {
      need_disk_read = true;
      if (!free_frames_.empty()) 
      {
        frame_id = free_frames_.front();
        free_frames_.pop_front();
      } else if (auto victim_id = replacer_->Evict()) {
        frame_id = *victim_id;
        
        // 处理被驱逐的页面
        for (const auto &[pid, fid] : page_table_) {
          if (fid == frame_id) {
            old_page_id = pid;
            break;
          }
        }
        
        if (old_page_id != INVALID_PAGE_ID) {
          // 如果是脏页，复制数据用于写回
          char* data_copy = nullptr;
          bool is_dirty = false;
          {
            // 仅在复制数据时短暂持有锁
            std::unique_lock<std::shared_mutex> victim_lock(frames_[frame_id]->rwlatch_);
            if (frames_[frame_id]->is_dirty_) {
              is_dirty = true;
              data_copy = new char[BUSTUB_PAGE_SIZE];
              std::memcpy(data_copy, frames_[frame_id]->GetData(), BUSTUB_PAGE_SIZE);
            }
            // 从页表中移除这个条目
            page_table_.erase(old_page_id);
            // 锁在这里自动释放
          }
          
          // 如果需要写回磁盘，在释放锁后执行
          if (is_dirty && data_copy != nullptr) {
            auto promise = disk_scheduler_->CreatePromise();
            auto future = promise.get_future();
            
            DiskRequest request;
            request.is_write_ = true;
            request.data_ = data_copy;
            request.page_id_ = old_page_id;
            request.callback_ = std::move(promise);
            
            disk_scheduler_->Schedule(std::move(request));
            future.get();
            
            delete[] data_copy;
          }
        }
        frames_[frame_id]->Reset();
        } 
      else // 只有在Evict()返回std::nullopt时才返回std::nullopt
      {
        return std::nullopt;
      }
      
      // 建议修改为（更安全的顺序）
frames_[frame_id]->pin_count_.fetch_add(1); // 首先增加pin计数
replacer_->RecordAccess(frame_id, access_type);  // 记录访问
replacer_->SetEvictable(frame_id, false);  // 设置不可驱逐
frame = frames_[frame_id];  // 获取帧引用
page_table_[page_id] = frame_id;  // 最后才使页面对其他线程可见
    }
  } // 在此处释放 bpm_latch_
  for (const auto& [pid, data_copy] : pages_to_flush) {
    // 直接使用底层API刷盘，不使用WritePageGuard
    auto promise = disk_scheduler_->CreatePromise();
    auto future = promise.get_future();
    
    DiskRequest request;
    request.is_write_ = true;
    request.data_ = data_copy;
    request.page_id_ = pid;
    request.callback_ = std::move(promise);
    
    disk_scheduler_->Schedule(std::move(request));
    
    future.get();  // 等待写入完成
    
    // 释放内存
    delete[] data_copy;
  }
  
  // 如果需要从磁盘读取页面，在释放 bpm_latch_ 后进行
  if (need_disk_read) {
    // 获取帧的独占锁，确保在读取和初始化期间没有其他线程访问该帧
    std::unique_lock<std::shared_mutex> frame_lock(frame->rwlatch_);

    auto promise = disk_scheduler_->CreatePromise();
    auto future = promise.get_future();
    
    // 正确创建DiskRequest对象
    DiskRequest request;
    request.is_write_ = false;
    request.data_ = frame->GetDataMut();
    request.page_id_ = page_id;
    request.callback_ = std::move(promise);
    
    disk_scheduler_->Schedule(std::move(request));
    
    future.get(); // 等待读取完成
    // 初始化页面头部数据
  }
  
  // 返回WritePageGuard
  return WritePageGuard(page_id, frame, replacer_, bpm_latch_, disk_scheduler_);
}

/**
 * @brief Acquires an optional read-locked guard over a page of data. The user can specify an `AccessType` if needed.
 *
 * If it is not possible to bring the page of data into memory, this function will return a `std::nullopt`.
 *
 * Page data can _only_ be accessed via page guards. Users of this `BufferPoolManager` are expected to acquire either a
 * `ReadPageGuard` or a `WritePageGuard` depending on the mode in which they would like to access the data, which
 * ensures that any access of data is thread-safe.
 *
 * There can be any number of `ReadPageGuard`s reading the same page of data at a time across different threads.
 * However, all data access must be immutable. If a user wants to mutate the page's data, they must acquire a
 * `WritePageGuard` with `CheckedWritePage` instead.
 *
 * ### Implementation
 *
 * See the implementation details of `CheckedWritePage`.
 *
 * TODO(P1): Add implementation.
 *
 * @param page_id The ID of the page we want to read.
 * @param access_type The type of page access.
 * @return std::optional<ReadPageGuard> An optional latch guard where if there are no more free frames (out of memory)
 * returns `std::nullopt`, otherwise returns a `ReadPageGuard` ensuring shared and read-only access to a page's data.
 */
 auto BufferPoolManager::CheckedReadPage(page_id_t page_id, AccessType access_type) -> std::optional<ReadPageGuard> {
  if (page_id == INVALID_PAGE_ID) {
    return std::nullopt;
  }
  std::shared_ptr<FrameHeader> frame;
  frame_id_t frame_id;
  bool need_disk_read = false;
  page_id_t old_page_id = INVALID_PAGE_ID;
  
  // 收集需要在释放锁后刷新的页面信息
  std::vector<std::pair<page_id_t, char*>> pages_to_flush;
  // 首先尝试查找页面并获取帧，短暂持有 bpm_latch_
  {
    std::lock_guard<std::mutex> guard(*bpm_latch_);
    
    // 检查页面是否已在缓冲池中
    auto it = page_table_.find(page_id);
    if (it != page_table_.end()) 
    {
      // 页面在缓冲池中
      frame_id = it->second;
      frame = frames_[frame_id];
      
      // 只有当这个不是一个新创建的页面时才增加pin计数
        frame->pin_count_.fetch_add(1);
      
      // 记录访问
      replacer_->RecordAccess(frame_id, access_type);
      replacer_->SetEvictable(frame_id, false);
    } 
    else 
    {
      // 页面不在缓冲池中，需要从磁盘加载
      need_disk_read = true;
      
      // 尝试获取空闲帧或驱逐一个页面
      if (!free_frames_.empty()) 
      {
        frame_id = free_frames_.front();
        free_frames_.pop_front();
      } 
      else if (auto victim_id = replacer_->Evict()) 
      {
        frame_id = *victim_id;
        
        // 处理被驱逐的页面
        for (const auto &[pid, fid] : page_table_) 
        {
          if (fid == frame_id) 
          {
            old_page_id = pid;
            break;
          }
        }
        
        if (old_page_id != INVALID_PAGE_ID) {
          // 如果是脏页，复制数据用于写回
          char* data_copy = nullptr;
          bool is_dirty = false;
          {
            // 仅在复制数据时短暂持有锁
            std::unique_lock<std::shared_mutex> victim_lock(frames_[frame_id]->rwlatch_);
            if (frames_[frame_id]->is_dirty_) {
              is_dirty = true;
              data_copy = new char[BUSTUB_PAGE_SIZE];
              std::memcpy(data_copy, frames_[frame_id]->GetData(), BUSTUB_PAGE_SIZE);
            }
            // 从页表中移除这个条目
            page_table_.erase(old_page_id);
            // 锁在这里自动释放
          }
          
          // 如果需要写回磁盘，在释放锁后执行
          if (is_dirty && data_copy != nullptr) {
            auto promise = disk_scheduler_->CreatePromise();
            auto future = promise.get_future();
            
            DiskRequest request;
            request.is_write_ = true;
            request.data_ = data_copy;
            request.page_id_ = old_page_id;
            request.callback_ = std::move(promise);
            
            disk_scheduler_->Schedule(std::move(request));
            future.get();
            
            delete[] data_copy;
          }
        }
        frames_[frame_id]->Reset();
      } 
      else 
      {
        // 无法找到可用帧
        return std::nullopt;
      }
      
      // 移除注释并实际应用这个更安全的顺序
frames_[frame_id]->pin_count_.fetch_add(1);  // 首先增加pin计数
replacer_->RecordAccess(frame_id, access_type);  // 记录访问
replacer_->SetEvictable(frame_id, false);  // 设置不可驱逐
frame = frames_[frame_id];  // 获取帧引用
page_table_[page_id] = frame_id;  // 最后才使页面对其他线程可见
    }
  } // 在此处释放 bpm_latch_
  
  // 在释放锁后刷新脏页
  for (const auto& [pid, data_copy] : pages_to_flush) 
  {
    // 直接使用底层API刷盘，不使用WritePageGuard
    auto promise = disk_scheduler_->CreatePromise();
    auto future = promise.get_future();
    
    DiskRequest request;
    request.is_write_ = true;
    request.data_ = data_copy;
    request.page_id_ = pid;
    request.callback_ = std::move(promise);
    
    disk_scheduler_->Schedule(std::move(request));
    
    future.get();  // 等待写入完成
    
    // 释放内存
    delete[] data_copy;
  }
  
  // 如果需要从磁盘读取页面，在释放 bpm_latch_ 后进行
  if (need_disk_read) {
    // 【添加】获取帧锁以保护页面数据
    std::unique_lock<std::shared_mutex> frame_lock(frame->rwlatch_);

    auto promise = disk_scheduler_->CreatePromise();
    auto future = promise.get_future();
    
    // 正确创建DiskRequest对象
    DiskRequest request;
    request.is_write_ = false;
    request.data_ = frame->GetDataMut();
    request.page_id_ = page_id;
    request.callback_ = std::move(promise);
    
    disk_scheduler_->Schedule(std::move(request));  
    
    future.get(); // 等待读取完成
    // 在这里初始化页面头部
   
  }
  
  // 返回ReadPageGuard
  return ReadPageGuard(page_id, frame, replacer_, bpm_latch_, disk_scheduler_);
}

/**
 * @brief A wrapper around `CheckedWritePage` that unwraps the inner value if it exists.
 *
 * If `CheckedWritePage` returns a `std::nullopt`, **this function aborts the entire process.**
 *
 * This function should **only** be used for testing and ergonomic's sake. If it is at all possible that the buffer pool
 * manager might run out of memory, then use `CheckedPageWrite` to allow you to handle that case.
 *
 * See the documentation for `CheckedPageWrite` for more information about implementation.
 *
 * @param page_id The ID of the page we want to read.
 * @param access_type The type of page access.
 * @return WritePageGuard A page guard ensuring exclusive and mutable access to a page's data.
 */
auto BufferPoolManager::WritePage(page_id_t page_id, AccessType access_type) -> WritePageGuard {
  auto guard_opt = CheckedWritePage(page_id, access_type);

  if (!guard_opt.has_value()) {
    fmt::println(stderr, "\n`CheckedWritePage` failed to bring in page {}\n", page_id);
    std::abort();
  }

  return std::move(guard_opt).value();
}

/**
 * @brief A wrapper around `CheckedReadPage` that unwraps the inner value if it exists.
 *
 * If `CheckedReadPage` returns a `std::nullopt`, **this function aborts the entire process.**
 *
 * This function should **only** be used for testing and ergonomic's sake. If it is at all possible that the buffer pool
 * manager might run out of memory, then use `CheckedPageWrite` to allow you to handle that case.
 *
 * See the documentation for `CheckedPageRead` for more information about implementation.
 *
 * @param page_id The ID of the page we want to read.
 * @param access_type The type of page access.
 * @return ReadPageGuard A page guard ensuring shared and read-only access to a page's data.
 */
auto BufferPoolManager::ReadPage(page_id_t page_id, AccessType access_type) -> ReadPageGuard {
  auto guard_opt = CheckedReadPage(page_id, access_type);

  if (!guard_opt.has_value()) {
    fmt::println(stderr, "\n`CheckedReadPage` failed to bring in page {}\n", page_id);
    std::abort();
  }

  return std::move(guard_opt).value();
}

/**
 * @brief Flushes a page's data out to disk unsafely.
 *
 * This function will write out a page's data to disk if it has been modified. If the given page is not in memory, this
 * function will return `false`.
 *
 * You should not take a lock on the page in this function.
 * This means that you should carefully consider when to toggle the `is_dirty_` bit.
 *
 * ### Implementation
 *
 * You should probably leave implementing this function until after you have completed `CheckedReadPage` and
 * `CheckedWritePage`, as it will likely be much easier to understand what to do.
 *
 * TODO(P1): Add implementation
 *
 * @param page_id The page ID of the page to be flushed.
 * @return `false` if the page could not be found in the page table, otherwise `true`.
 */
auto BufferPoolManager::FlushPageUnsafe(page_id_t page_id) -> bool { 
  // 无效的页ID
  if (page_id == INVALID_PAGE_ID) {
    return false;
  }
  
  // 检查页面是否在缓冲池中
  std::lock_guard<std::mutex> guard(*bpm_latch_);
  auto it = page_table_.find(page_id);
  if (it == page_table_.end()) {
    // 页面不在缓冲池中
    return false;
  }
  
  frame_id_t frame_id = it->second;
  auto frame = frames_[frame_id];
  
  // 如果页面是脏页，将其写回磁盘
  if (frame->is_dirty_) {
    auto promise = disk_scheduler_->CreatePromise();
    auto future = promise.get_future();
    
    disk_scheduler_->Schedule({
      .is_write_ = true,
      .data_ = frame->GetDataMut(),
      .page_id_ = page_id,
      .callback_ = std::move(promise)
    });
    
    future.get();  // 等待写入完成
    
    // 写入后清除脏位
    frame->is_dirty_ = false;
  }
  
  return true;
 }

/**
 * @brief Flushes a page's data out to disk safely.
 *
 * This function will write out a page's data to disk if it has been modified. If the given page is not in memory, this
 * function will return `false`.
 *
 * You should take a lock on the page in this function to ensure that a consistent state is flushed to disk.
 *
 * ### Implementation
 *
 * You should probably leave implementing this function until after you have completed `CheckedReadPage`,
 * `CheckedWritePage`, and `Flush` in the page guards, as it will likely be much easier to understand what to do.
 *
 * TODO(P1): Add implementation
 *
 * @param page_id The page ID of the page to be flushed.
 * @return `false` if the page could not be found in the page table, otherwise `true`.
 */
auto BufferPoolManager::FlushPage(page_id_t page_id) -> bool { 
 // 无效的页ID
 if (page_id == INVALID_PAGE_ID) {
  return false;
}

auto page_guard_opt = CheckedWritePage(page_id);
  if (!page_guard_opt.has_value()) {
    return false;
  }

  auto &page_guard = page_guard_opt.value();
  page_guard.Flush();
  return true;
}

/**
 * @brief Flushes all page data that is in memory to disk unsafely.
 *
 * You should not take locks on the pages in this function.
 * This means that you should carefully consider when to toggle the `is_dirty_` bit.
 *
 * ### Implementation
 *
 * You should probably leave implementing this function until after you have completed `CheckedReadPage`,
 * `CheckedWritePage`, and `FlushPage`, as it will likely be much easier to understand what to do.
 *
 * TODO(P1): Add implementation
 */
void BufferPoolManager::FlushAllPagesUnsafe() {
  // 复制要刷写的页面信息，然后释放全局锁
  std::vector<std::pair<page_id_t, char*>> pages_to_flush;
  
  {
    std::lock_guard<std::mutex> guard(*bpm_latch_);
    for (const auto &[page_id, frame_id] : page_table_) {
      auto frame = frames_[frame_id];
      if (frame->is_dirty_) {
        char* data_copy = new char[BUSTUB_PAGE_SIZE];
        std::memcpy(data_copy, frame->GetData(), BUSTUB_PAGE_SIZE);
        pages_to_flush.emplace_back(page_id, data_copy);
        frame->is_dirty_ = false;
      }
    }
  }
  
  // 在释放锁后执行I/O
  for (const auto &[page_id, data] : pages_to_flush) {
    auto promise = disk_scheduler_->CreatePromise();
    auto future = promise.get_future();
    
    DiskRequest request;
    request.is_write_ = true;
    request.data_ = data;
    request.page_id_ = page_id;
    request.callback_ = std::move(promise);
    
    disk_scheduler_->Schedule(std::move(request));
    future.get();
    
    delete[] data;
  }
}

/**
 * @brief Flushes all page data that is in memory to disk safely.
 *
 * You should take locks on the pages in this function to ensure that a consistent state is flushed to disk.
 *
 * ### Implementation
 *
 * You should probably leave implementing this function until after you have completed `CheckedReadPage`,
 * `CheckedWritePage`, and `FlushPage`, as it will likely be much easier to understand what to do.
 *
 * TODO(P1): Add implementation
 */
void BufferPoolManager::FlushAllPages() { 
  // 首先获取所有页面的ID和帧ID
  std::vector<std::pair<page_id_t, frame_id_t>> pages_to_flush;
  
  {
    std::lock_guard<std::mutex> guard(*bpm_latch_);
    for (const auto &[page_id, frame_id] : page_table_) {
      pages_to_flush.emplace_back(page_id, frame_id);
    }
  }
  
  // 然后单独处理每个页面，减少全局锁的持有时间
  for (const auto &[page_id, frame_id] : pages_to_flush) {
    FlushPage(page_id);
  }
 }

/**
 * @brief Retrieves the pin count of a page. If the page does not exist in memory, return `std::nullopt`.
 *
 * This function is thread safe. Callers may invoke this function in a multi-threaded environment where multiple threads
 * access the same page.
 *
 * This function is intended for testing purposes. If this function is implemented incorrectly, it will definitely cause
 * problems with the test suite and autograder.
 *
 * # Implementation
 *
 * We will use this function to test if your buffer pool manager is managing pin counts correctly. Since the
 * `pin_count_` field in `FrameHeader` is an atomic type, you do not need to take the latch on the frame that holds the
 * page we want to look at. Instead, you can simply use an atomic `load` to safely load the value stored. You will still
 * need to take the buffer pool latch, however.
 *
 * Again, if you are unfamiliar with atomic types, see the official C++ docs
 * [here](https://en.cppreference.com/w/cpp/atomic/atomic).
 *
 * TODO(P1): Add implementation
 *
 * @param page_id The page ID of the page we want to get the pin count of.
 * @return std::optional<size_t> The pin count if the page exists, otherwise `std::nullopt`.
 */
auto BufferPoolManager::GetPinCount(page_id_t page_id) -> std::optional<size_t> {
  std::lock_guard<std::mutex> guard(*bpm_latch_);
  
  // 检查页面是否在缓冲池中
  auto it = page_table_.find(page_id);
  if (it == page_table_.end()) {
    // 页面不在缓冲池中
    return std::nullopt;
  }
  
  frame_id_t frame_id = it->second;
  auto frame = frames_[frame_id];
  
  // 使用原子load操作获取pin计数
  return frame->pin_count_.load();
}

}  // namespace bustub
