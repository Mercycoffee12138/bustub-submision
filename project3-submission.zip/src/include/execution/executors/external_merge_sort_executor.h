#pragma once

#include <cstddef>
#include <memory>
#include <utility>
#include <vector>
#include <queue>
#include "common/config.h"
#include "common/macros.h"
#include "execution/execution_common.h"
#include "execution/executors/abstract_executor.h"
#include "execution/plans/sort_plan.h"
#include "storage/table/tuple.h"
#include "storage/page/page_guard.h"
#include "buffer/buffer_pool_manager.h"

namespace bustub {

/**
 * Page to hold the intermediate data for external merge sort.
 * Only fixed-length data will be supported in Fall 2024.
 */
class SortPage {
 public:
  SortPage() = default;
  
  void WriteTuple(const Tuple &tuple, const Schema &schema);
  auto ReadTuple(size_t index, const Schema &schema) -> Tuple;
  auto ReadTuple(size_t index, const Schema &schema) const -> Tuple;
  auto GetTupleCount() const -> size_t { return tuple_count_; }
  auto CanAddTuple(const Tuple &tuple) const -> bool;
  void SortTuples(const std::vector<std::pair<OrderByType, AbstractExpressionRef>> &order_bys, 
                  const Schema &schema);

 private:
  size_t tuple_count_{0};
  static constexpr size_t MAX_TUPLES = 256;
  char data_[BUSTUB_PAGE_SIZE - sizeof(size_t) - MAX_TUPLES * sizeof(size_t)];
  size_t tuple_offsets_[MAX_TUPLES];
};

/**
 * A sorted run for external merge sort.
 */
class MergeSortRun {
 public:
  MergeSortRun(std::vector<page_id_t> pages, BufferPoolManager *bpm) 
      : pages_(std::move(pages)), bpm_(bpm) {}

  class Iterator {
    friend class MergeSortRun;

   public:
    Iterator() = default;
    
    auto operator++() -> Iterator & {
      ++tuple_index_;
      
      // 检查当前页面是否还有元组
      if (current_guard_.has_value()) {
        auto sort_page = reinterpret_cast<const SortPage *>(current_guard_->GetData());
        if (tuple_index_ >= sort_page->GetTupleCount()) {
          // 当前页面已完成，移动到下一页
          ++page_index_;
          tuple_index_ = 0;
          LoadCurrentPage();
        }
      }
      
      return *this;
    }

    auto operator*() const -> Tuple {
      if (!current_guard_.has_value() || page_index_ >= run_->pages_.size()) {
        return Tuple{};
      }
      
      auto sort_page = reinterpret_cast<const SortPage *>(current_guard_->GetData());
      
      // 关键修复：确保使用正确的 Schema 引用
      return sort_page->ReadTuple(tuple_index_, *schema_);
    }

    auto operator==(const Iterator &other) const -> bool {
      return run_ == other.run_ && 
             page_index_ == other.page_index_ && 
             tuple_index_ == other.tuple_index_;
    }

    auto operator!=(const Iterator &other) const -> bool {
      return !(*this == other);
    }

   private:
    explicit Iterator(const MergeSortRun *run, const Schema &schema, size_t page_idx = 0, size_t tuple_idx = 0)
        : run_(run), schema_(&schema), page_index_(page_idx), tuple_index_(tuple_idx) {
      LoadCurrentPage();
    }
    
    void LoadCurrentPage() {
      current_guard_.reset();
      
      if (page_index_ < run_->pages_.size()) {
        auto guard_opt = run_->bpm_->CheckedReadPage(run_->pages_[page_index_]);
        if (guard_opt.has_value()) {
          current_guard_ = std::move(guard_opt.value());
        }
      }
    }

    const MergeSortRun *run_{nullptr};
    const Schema *schema_{nullptr};  // 存储 Schema 指针
    size_t page_index_{0};
    size_t tuple_index_{0};
    mutable std::optional<ReadPageGuard> current_guard_;
  };

  auto Begin(const Schema &schema) -> Iterator { 
    return Iterator(this, schema, 0, 0); 
  }

  auto End(const Schema &schema) -> Iterator { 
    return Iterator(this, schema, pages_.size(), 0); 
  }

 private:
  std::vector<page_id_t> pages_;
  BufferPoolManager *bpm_;
};

template <size_t K>
class ExternalMergeSortExecutor : public AbstractExecutor {
 public:
  ExternalMergeSortExecutor(ExecutorContext *exec_ctx, const SortPlanNode *plan,
                            std::unique_ptr<AbstractExecutor> &&child_executor);

  void Init() override;
  auto Next(Tuple *tuple, RID *rid) -> bool override;
  auto GetOutputSchema() const -> const Schema & override { return plan_->OutputSchema(); }

 private:
  const SortPlanNode *plan_;
  std::unique_ptr<AbstractExecutor> child_executor_;
  std::vector<MergeSortRun> runs_;
  std::vector<MergeSortRun::Iterator> run_iterators_;
  bool initialized_{false};
  
  // 添加调试成员
  std::vector<Tuple> sorted_tuples_;
  size_t current_index_{0};
};

}  // namespace bustub