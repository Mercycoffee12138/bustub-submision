//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nested_loop_join_executor.cpp
//
// Identification: src/execution/nested_loop_join_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include "execution/executors/nested_loop_join_executor.h"
#include <cstdint>
#include <memory>
#include <utility>
#include <vector>
#include "binder/table_ref/bound_join_ref.h"
#include "catalog/schema.h"
#include "common/exception.h"
#include "common/rid.h"
#include "storage/table/tuple.h"
#include "type/value.h"
#include "type/value_factory.h"

namespace bustub {

/**
 * Construct a new NestedLoopJoinExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The nested loop join plan to be executed
 * @param left_executor The child executor that produces tuple for the left side of join
 * @param right_executor The child executor that produces tuple for the right side of join
 */
NestedLoopJoinExecutor::NestedLoopJoinExecutor(ExecutorContext *exec_ctx, const NestedLoopJoinPlanNode *plan,
                                               std::unique_ptr<AbstractExecutor> &&left_executor,
                                               std::unique_ptr<AbstractExecutor> &&right_executor)
    : AbstractExecutor(exec_ctx) ,
      plan_(plan),
      left_executor_(std::move(left_executor)),
      right_executor_(std::move(right_executor)){
  if (!(plan->GetJoinType() == JoinType::LEFT || plan->GetJoinType() == JoinType::INNER)) {
    // Note for 2023 Fall: You ONLY need to implement left join and inner join.
    throw bustub::NotImplementedException(fmt::format("join type {} not supported", plan->GetJoinType()));
  }
}

/** Initialize the join */
void NestedLoopJoinExecutor::Init() {
  left_executor_->Init();
  right_executor_->Init();
  std::cout << plan_->ToString() << std::endl;
  RID tmp_rid;
  left_status_ = left_executor_->Next(&left_cur_tuple_, &tmp_rid);
  tuple_match_ = false;
  right_started_ = false;
}
auto NestedLoopJoinExecutor::InnerJoin() -> bool { return true; }

auto NestedLoopJoinExecutor::LeftJoin() -> bool { return true; }
/**
 * Yield the next tuple from the join.
 * @param[out] tuple The next tuple produced by the join
 * @param[out] rid The next tuple RID produced, not used by nested loop join.
 * @return `true` if a tuple was produced, `false` if there are no more tuples.
 */
auto NestedLoopJoinExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  //std::cout << "000" << std::endl;
  
  auto filter_expr = plan_->predicate_;
  // Tuple left_tuple{};
  Tuple right_tuple{};
  RID left_rid{};
  RID right_rid{};
  Schema left_schema = plan_->GetLeftPlan()->OutputSchema();
  Schema right_schema = plan_->GetRightPlan()->OutputSchema();
  // right_executor_->Init();  //每次都要重置right table

  while (true) {
    if (!left_status_) {
      return false;
    }

    // 嵌套循环
    while (true) {
      //std::cout << "111" << std::endl;
      auto right_status = right_executor_->Next(&right_tuple, &right_rid);
      
      /*std::cout << "right_status: " << right_status 
                << ", current_right_count: " << current_right_count 
                << ", right_table_size: " << right_table_size << std::endl;*/
      
      // 如果右表大小还未记录，且 right_status 为 false，则记录右表大小
      if (right_table_size == -1 && !right_status) {
        right_table_size = current_right_count;  // 直接使用当前计数，不减1
        //std::cout << "[嵌套循环连接::Next] 记录右表大小: " << right_table_size << std::endl;
      }
      
      // 判断是否应该结束当前左元组的右表遍历
      bool should_end_right_scan = false;
      if (right_table_size == -1) {
        // 第一次遍历，依赖 right_status
        should_end_right_scan = !right_status;
      } else {
        // 后续遍历，依赖计数
        should_end_right_scan = (current_right_count >= right_table_size);
      }
      
      if (should_end_right_scan) {  //已经找完right table的元素了
        //std::cout << "[嵌套循环连接::Next] 内层循环: 对于当前左元组，右侧执行器已耗尽。" << std::endl;
        // 对应left join, 开始添加null。对于inner, 则直接进入下一次循环
        // 如果这个left tuple在当前轮次已经找到过对应的right tuple就跳过这一步
        //std::cout << "333" << std::endl;
        if (plan_->join_type_ == JoinType::LEFT && !tuple_match_) {
          std::vector<Value> result;
          Value cur_val;  // 当前列的value值
          // 提取左表所有的列元素
          for (uint32_t i = 0; i < left_schema.GetColumnCount(); i++) {
            cur_val = left_cur_tuple_.GetValue(&left_schema, i);
            result.emplace_back(cur_val);
          }
          // 右表没有匹配的tuple, 生成空值就行了
          for (uint32_t i = 0; i < right_schema.GetColumnCount(); i++) {
            cur_val = ValueFactory::GetNullValueByType(right_schema.GetColumn(i).GetType());
            result.emplace_back(cur_val);
          }
          *tuple = Tuple{result, &plan_->OutputSchema()};
          // tuple_match_=true;  // 这个left tuple遍历到right table的末尾了, 不算找到
          //std::cout << "[嵌套循环连接::Next] 重新初始化右侧执行器并获取下一个左元组" << std::endl;
          right_executor_->Init();
          current_right_count = 0;  // 重置右表计数
          left_status_ = left_executor_->Next(&left_cur_tuple_, &left_rid);
          return true;
        }
        //std::cout << "444" << std::endl;
        //std::cout << "[嵌套循环连接::Next] 重新初始化右侧执行器并获取下一个左元组" << std::endl;
        right_executor_->Init();
        current_right_count = 0;  // 重置右表计数
        left_status_ = left_executor_->Next(&left_cur_tuple_, &left_rid);
        tuple_match_ = false;
        break;
      }
      
      // 只有当 right_status 为 true 时，才增加计数（表示获得了有效数据）
      if (right_status) {
        current_right_count++;  // 移到这里，只在有效数据时计数
        
        /*std::cout << "[嵌套循环连接::Next] 评估谓词: " << plan_->Predicate()->ToString()
                  << " \n  左元组: " << left_cur_tuple_.ToString(&left_schema)
                  << " \n  右元组: " << right_tuple.ToString(&right_schema) << std::endl;*/
        // 判断两个tuple是否符合pred  value的类型为bool
        auto value = plan_->Predicate()->EvaluateJoin(&left_cur_tuple_, left_schema, &right_tuple, right_schema);

        if (!value.IsNull() && value.GetAs<bool>()) {  // 何时value会为空呢?我很好奇
          // 提取左表和右表所有的列元素
          std::vector<Value> result;
          Value cur_val;  // 当前列的value值
          for (uint32_t i = 0; i < left_schema.GetColumnCount(); i++) {
            cur_val = left_cur_tuple_.GetValue(&left_schema, i);
            result.emplace_back(cur_val);
          }
          for (uint32_t i = 0; i < right_schema.GetColumnCount(); i++) {
            cur_val = right_tuple.GetValue(&right_schema, i);
            result.emplace_back(cur_val);
          }
          *tuple = Tuple{result, &plan_->OutputSchema()};
          //std::cout << "[嵌套循环连接::Next] 生成的匹配元组: " << tuple->ToString(&plan_->OutputSchema()) << std::endl;
          tuple_match_ = true;  // 这个left tuple已经找到对应的right tuple了
          return true;
        }
      } else {
        // right_status 为 false，说明没有更多数据，但我们不增加计数
        //std::cout << "[嵌套循环连接::Next] right_status 为 false，无有效数据" << std::endl;
      }
    }
  }

  return false;
}


}  // namespace bustub
