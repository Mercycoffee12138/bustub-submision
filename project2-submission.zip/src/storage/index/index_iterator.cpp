//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// index_iterator.cpp
//
// Identification: src/storage/index/index_iterator.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

/**
 * index_iterator.cpp
 */
#include <cassert>

#include "storage/index/index_iterator.h"

namespace bustub {

/**
 * @note you can change the destructor/constructor method here
 * set your own input parameters
 */
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator()
    : page_id_(INVALID_PAGE_ID), index_(0), buffer_pool_manager_(nullptr), is_end_(true) {}

/**
 * 带参数的构造函数
 */
 INDEX_TEMPLATE_ARGUMENTS
 INDEXITERATOR_TYPE::IndexIterator(page_id_t page_id, int index, BufferPoolManager *buffer_pool_manager) 
     : page_id_(page_id), index_(index), buffer_pool_manager_(buffer_pool_manager) {
   // 检查是否是结束迭代器
   is_end_ = (page_id == INVALID_PAGE_ID);
   
   // 如果不是结束迭代器，获取页面
   if (!is_end_) {
     page_guard_ = buffer_pool_manager->ReadPage(page_id);
   }
 }

 INDEX_TEMPLATE_ARGUMENTS
 INDEXITERATOR_TYPE::~IndexIterator() {
   // 确保所有页面资源被释放
   if (page_guard_.has_value()) {
     page_guard_.reset();
   }
 }

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::IsEnd() -> bool { 
  return is_end_; 
 }

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator*() -> std::pair<const KeyType &, const ValueType &> {
  // 确保迭代器不是结束迭代器
  assert(!is_end_);
  
  // 确保页面守卫有效
  assert(page_guard_.has_value());
  
  // 获取叶节点页面
  auto leaf_page = page_guard_.value().As<BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>>();
  
  // 确保索引在有效范围内
  assert(index_ >= 0 && index_ < leaf_page->GetSize());
  
  // 返回当前键值对
  return {leaf_page->KeyAt(index_), leaf_page->ValueAt(index_)};
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator++() -> INDEXITERATOR_TYPE & { 
   // 确保迭代器不是结束迭代器
  if (is_end_) {
    return *this;
  }

  // 确保页面守卫有效
  if (!page_guard_.has_value()) {
    is_end_ = true;
    return *this;
  }
  
  // 获取叶节点页面
  auto leaf_page = page_guard_.value().As<BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>>();
  // 增加索引
  index_++;
  // 检查是否到达当前页面的末尾
  if (index_ >= leaf_page->GetSize()) {
    // 获取下一个页面ID
    page_id_t next_page_id = leaf_page->GetNextPageId();
    // 释放当前页面的锁
    page_guard_.reset();
    // 如果没有下一页，迭代器到达末尾
    if (next_page_id == INVALID_PAGE_ID) {
      page_id_ = INVALID_PAGE_ID;
      index_ = 0;
      is_end_ = true;
      return *this;
    }
    // 获取下一个页面
    page_id_ = next_page_id;
    index_ = 0;
    page_guard_ = buffer_pool_manager_->ReadPage(page_id_);
    // 安全检查：确保页面获取成功
    if (!page_guard_.has_value()) {
      // 页面获取失败，将迭代器设为结束状态
      is_end_ = true;
      page_id_ = INVALID_PAGE_ID;
      index_ = 0;
    }
  }
  return *this;
}

 INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator==(const IndexIterator &itr) const -> bool {
  // 如果两个迭代器都是结束迭代器，则它们相等
  if (is_end_ && itr.is_end_) {
    return true;
  }
  // 否则，比较页面ID和索引
  return page_id_ == itr.page_id_ && index_ == itr.index_;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator!=(const IndexIterator &itr) const -> bool { 
  return !(*this == itr);
}

template class IndexIterator<GenericKey<4>, RID, GenericComparator<4>>;

template class IndexIterator<GenericKey<8>, RID, GenericComparator<8>>;

template class IndexIterator<GenericKey<16>, RID, GenericComparator<16>>;

template class IndexIterator<GenericKey<32>, RID, GenericComparator<32>>;

template class IndexIterator<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
