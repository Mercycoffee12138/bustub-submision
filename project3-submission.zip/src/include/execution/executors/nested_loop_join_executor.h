//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nested_loop_join_executor.h
//
// Identification: src/include/execution/executors/nested_loop_join_executor.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <memory>
#include <utility>
#include <vector>

#include "common/rid.h"
#include "execution/executor_context.h"
#include "execution/executors/abstract_executor.h"
#include "execution/plans/abstract_plan.h"
#include "execution/plans/nested_loop_join_plan.h"
#include "storage/table/tuple.h"

namespace bustub {

/**
 * NestedLoopJoinExecutor executes a nested-loop JOIN on two tables.
 */
class NestedLoopJoinExecutor : public AbstractExecutor {
 public:
  NestedLoopJoinExecutor(ExecutorContext *exec_ctx, const NestedLoopJoinPlanNode *plan,
                         std::unique_ptr<AbstractExecutor> &&left_executor,
                         std::unique_ptr<AbstractExecutor> &&right_executor);

  void Init() override;

  auto Next(Tuple *tuple, RID *rid) -> bool override;

  /** @return The output schema for the insert */
  auto GetOutputSchema() const -> const Schema & override { return plan_->OutputSchema(); };

  /** inner连接 **/
  auto InnerJoin()->bool;

  /** left连接 **/
  auto LeftJoin()->bool;

 private:
  /** The NestedLoopJoin plan node to be executed. */
  const NestedLoopJoinPlanNode *plan_;
  std::unique_ptr<AbstractExecutor> left_executor_;
  std::unique_ptr<AbstractExecutor> right_executor_;
  //  std::vector<RID>::iterator left_table_iter_; // 左侧表的迭代器 naive方法中, 表是无序的, 用iter也没用
  Tuple left_cur_tuple_;  // 记录left table正在处理的元组
  RID left_rid_; 
  bool left_status_;  // 此次获取left table的元素是否成功
  bool left_has_match_;  // 新增：用于跟踪当前左元组是否找到过匹配
  bool tuple_match_;
  bool right_started_;
  int right_table_size = -1;  // 静态变量记录右表大小，-1表示未初始化
  int current_right_count = 0;  // 当前右表遍历计数
};

}  // namespace bustub
