//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// delete_executor.cpp
//
// Identification: src/execution/delete_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <memory>

#include "execution/executors/delete_executor.h"

namespace bustub {

/**
 * Construct a new DeleteExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The delete plan to be executed
 * @param child_executor The child executor that feeds the delete
 */
DeleteExecutor::DeleteExecutor(ExecutorContext *exec_ctx, const DeletePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx) {
    plan_ = plan;
    child_executor_ = std::move(child_executor);
}

/** Initialize the delete */
void DeleteExecutor::Init() { 
    child_executor_->Init();
    delete_finish_ = false;
}

/**
 * Yield the number of rows deleted from the table.
 * @param[out] tuple The integer tuple indicating the number of rows deleted from the table
 * @param[out] rid The next tuple RID produced by the delete (ignore, not used)
 * @return `true` if a tuple was produced, `false` if there are no more tuples
 *
 * NOTE: DeleteExecutor::Next() does not use the `rid` out-parameter.
 * NOTE: DeleteExecutor::Next() returns true with the number of deleted rows produced only once.
 */
auto DeleteExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
    if(delete_finish_){
        return false;
    }
    delete_finish_=true;
    TableInfo *table_info=GetExecutorContext()->GetCatalog()->GetTable(plan_->table_oid_).get();
    auto table_indexes=GetExecutorContext()->GetCatalog()->GetTableIndexes(table_info->name_);
    int cnt=0;  // 对删除的行数进行计数
    Tuple tmp_tuple{};
    RID tmp_rid{};
    while(child_executor_->Next(&tmp_tuple, &tmp_rid)){
        cnt++;
        table_info->table_->UpdateTupleMeta(TupleMeta{0,true}, tmp_rid);
        for(auto & index:table_indexes){
            auto old_key=tmp_tuple.KeyFromTuple(table_info->schema_, index->key_schema_, index->index_->GetKeyAttrs());
            index->index_->DeleteEntry(old_key, tmp_rid, GetExecutorContext()->GetTransaction());
        }
    }
    std::vector<Value> res={{TypeId::INTEGER,cnt}};
    *tuple=Tuple{res,&GetOutputSchema()};
    return true;
}

}  // namespace bustub
