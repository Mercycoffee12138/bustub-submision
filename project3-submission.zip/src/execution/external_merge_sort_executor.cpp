#include "execution/executors/external_merge_sort_executor.h"
#include <algorithm>
#include <iostream>
#include <optional>
#include <queue>
#include <vector>
#include "common/config.h"
#include "execution/plans/sort_plan.h"

namespace bustub {

void SortPage::WriteTuple(const Tuple &tuple, const Schema &schema) {
  // 检查是否超过最大元组数量
  if (tuple_count_ >= MAX_TUPLES) {
    return;
  }
  
  size_t tuple_size = tuple.GetLength();
  size_t serialized_size = tuple_size + sizeof(int32_t);  // 加上大小字段
  size_t offset = 0;
  
  // 计算当前数据偏移量
  for (size_t i = 0; i < tuple_count_; ++i) {
    offset += tuple_offsets_[i];
  }
  
  // 检查空间是否足够
  size_t available_space = sizeof(data_);
  if (offset + serialized_size > available_space) {
    return;  // 空间不足
  }
  
  // 调试
  if (tuple_count_ < 3) {
    std::cerr << "\n=== WriteTuple FIXED DEBUG ===" << std::endl;
    std::cerr << "Tuple: " << tuple.ToString(&schema) << std::endl;
    std::cerr << "Tuple size: " << tuple_size << std::endl;
    std::cerr << "Serialized size: " << serialized_size << std::endl;
    std::cerr << "Offset: " << offset << std::endl;
  }
  
  // 安全地序列化元组
  tuple.SerializeTo(data_ + offset);
  
  // 修复：存储实际写入的大小
  tuple_offsets_[tuple_count_] = serialized_size;  // ✅ 正确！
  
  // 验证
  if (tuple_count_ < 3) {
    std::cerr << "Written bytes: ";
    for (size_t i = 0; i < serialized_size; ++i) {
      std::cerr << std::hex << static_cast<int>(static_cast<unsigned char>(data_[offset + i])) << " ";
    }
    std::cerr << std::dec << std::endl;
    std::cerr << "=== End WriteTuple DEBUG ===" << std::endl;
  }
  
  ++tuple_count_;
}

auto SortPage::ReadTuple(size_t index, const Schema &schema) -> Tuple {
  if (index >= tuple_count_) {
    return Tuple{};
  }
  
  size_t offset = 0;
  for (size_t i = 0; i < index; ++i) {
    offset += tuple_offsets_[i];
  }
  
  Tuple tuple;
  tuple.DeserializeFrom(data_ + offset);
  return tuple;
}

auto SortPage::ReadTuple(size_t index, const Schema &schema) const -> Tuple {
  if (index >= tuple_count_) {
    return Tuple{};
  }
  
  size_t offset = 0;
  for (size_t i = 0; i < index; ++i) {
    offset += tuple_offsets_[i];
  }
  
  // 详细调试
  if (index < 3) {
    std::cerr << "\n=== ReadTuple DEBUG (index=" << index << ") ===" << std::endl;
    std::cerr << "Offset: " << offset << ", Size: " << tuple_offsets_[index] << std::endl;
    
    // 显示序列化数据的前 16 字节
    std::cerr << "Raw bytes at offset: ";
    for (size_t i = 0; i < std::min(tuple_offsets_[index], size_t(16)); ++i) {
      std::cerr << std::hex << static_cast<int>(static_cast<unsigned char>(data_[offset + i])) << " ";
    }
    std::cerr << std::dec << std::endl;
    
    // 读取大小字段
    uint32_t stored_size = *reinterpret_cast<const uint32_t *>(data_ + offset);
    std::cerr << "Stored size field: " << stored_size << std::endl;
    
    // 显示实际数据部分
    std::cerr << "Data bytes: ";
    for (size_t i = 4; i < std::min(tuple_offsets_[index], size_t(16)); ++i) {
      std::cerr << std::hex << static_cast<int>(static_cast<unsigned char>(data_[offset + i])) << " ";
    }
    std::cerr << std::dec << std::endl;
  }
  
  Tuple tuple;
  tuple.DeserializeFrom(data_ + offset);
  
  if (index < 3) {
    std::cerr << "Deserialized tuple: " << tuple.ToString(&schema) << std::endl;
    std::cerr << "=== End ReadTuple DEBUG ===" << std::endl;
  }
  
  return tuple;
}

auto SortPage::CanAddTuple(const Tuple &tuple) const -> bool {
  // 检查元组数量限制
  if (tuple_count_ >= MAX_TUPLES) {
    return false;
  }
  
  size_t current_size = 0;
  for (size_t i = 0; i < tuple_count_; ++i) {
    current_size += tuple_offsets_[i];
  }
  
  // 检查数据空间是否足够
  size_t available_space = sizeof(data_);
  return current_size + tuple.GetLength() <= available_space;
}

void SortPage::SortTuples(const std::vector<std::pair<OrderByType, AbstractExpressionRef>> &order_bys,
                          const Schema &schema) {
  // 读取所有元组并创建 SortEntry
  std::vector<SortEntry> entries;
  for (size_t i = 0; i < tuple_count_; ++i) {
    Tuple tuple = ReadTuple(i, schema);
    std::vector<Value> keys;
    
    // 提取排序键
    for (const auto &[order_type, expr] : order_bys) {
      keys.push_back(expr->Evaluate(&tuple, schema));
    }
    
    entries.emplace_back(std::move(keys), std::move(tuple));
  }
  
  // 使用 TupleComparator 排序
  TupleComparator cmp(order_bys);
  std::sort(entries.begin(), entries.end(), cmp);
  
  // 重新写入排序后的元组
  tuple_count_ = 0;
  for (const auto &entry : entries) {
    WriteTuple(entry.second, schema);
  }
}

template <size_t K>
ExternalMergeSortExecutor<K>::ExternalMergeSortExecutor(ExecutorContext *exec_ctx, const SortPlanNode *plan,
                                                        std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), 
      plan_(plan),
      child_executor_(std::move(child_executor)) {}

template <size_t K>
void ExternalMergeSortExecutor<K>::Init() {
  if (initialized_) {
    return;
  }
  
  child_executor_->Init();
  auto bpm = exec_ctx_->GetBufferPoolManager();
  
  // 调试：输出排序信息
  std::cerr << "=== Sort Debug Info ===" << std::endl;
  const auto &order_bys = plan_->GetOrderBy();
  for (size_t i = 0; i < order_bys.size(); ++i) {
    const auto &order_by = order_bys[i];
    std::cerr << "Sort column " << i << ": ";
    
    // 处理所有4种情况
    switch (order_by.first) {
      case OrderByType::INVALID:
        std::cerr << "INVALID (0)" << std::endl;
        break;
      case OrderByType::DEFAULT:
        std::cerr << "DEFAULT (1) - treated as ASC" << std::endl;
        break;
      case OrderByType::ASC:
        std::cerr << "ASC (2)" << std::endl;
        break;
      case OrderByType::DESC:
        std::cerr << "DESC (3)" << std::endl;
        break;
      default:
        std::cerr << "UNKNOWN (" << static_cast<int>(order_by.first) << ")" << std::endl;
        break;
    }
  }
  
  // 简化实现：收集所有数据进行内存排序
  std::vector<Tuple> all_tuples;
  Tuple tuple;
  RID rid;
  
  size_t tuple_count = 0;
while (child_executor_->Next(&tuple, &rid)) {
  // 调试：检查原始元组
  if (tuple_count < 3) {
    std::cerr << "Original tuple " << tuple_count << ":" << std::endl;
    std::cerr << "  ToString: " << tuple.ToString(&child_executor_->GetOutputSchema()) << std::endl;
    std::cerr << "  GetLength: " << tuple.GetLength() << std::endl;
    std::cerr << "  Raw bytes (" << tuple.GetLength() << "): ";
    for (size_t i = 0; i < tuple.GetLength(); ++i) {
      std::cerr << std::hex << static_cast<int>(static_cast<unsigned char>(tuple.GetData()[i])) << " ";
    }
    std::cerr << std::dec << std::endl;
    
    // 检查每列的值
    const auto &schema = child_executor_->GetOutputSchema();
    for (size_t col = 0; col < schema.GetColumnCount(); ++col) {
      Value val = tuple.GetValue(&schema, col);
      std::cerr << "  Column " << col << ": " << val.ToString() << std::endl;
    }
  }
  
  all_tuples.push_back(tuple);
  ++tuple_count;
}
  
  std::cerr << "Got " << all_tuples.size() << " tuples to sort" << std::endl;
  
  // 创建 SortEntry 并排序
  std::vector<SortEntry> entries;
  entries.reserve(all_tuples.size());
  
  for (auto &t : all_tuples) {
    std::vector<Value> keys;
    keys.reserve(order_bys.size());
    
    for (const auto &[order_type, expr] : order_bys) {
      Value key = expr->Evaluate(&t, child_executor_->GetOutputSchema());
      keys.push_back(key);
      
      // 调试：输出前几个键值和最后几个键值
      if (entries.size() < 3 || entries.size() >= all_tuples.size() - 3) {
        std::cerr << "Tuple " << entries.size() << " key: " << key.ToString() 
                  << " (order_type: " << static_cast<int>(order_type) << ")" << std::endl;
      }
    }
    
    entries.emplace_back(std::move(keys), std::move(t));
  }
  
  // 排序前：显示数据分布
  std::cerr << "\n=== Before Sorting ===" << std::endl;
  std::cerr << "First 3 entries:" << std::endl;
  for (size_t i = 0; i < std::min(size_t(3), entries.size()); ++i) {
    std::cerr << "Entry " << i << ": ";
    for (const auto &key : entries[i].first) {
      std::cerr << key.ToString() << " ";
    }
    std::cerr << std::endl;
  }
  
  if (entries.size() > 6) {
    std::cerr << "Last 3 entries:" << std::endl;
    for (size_t i = entries.size() - 3; i < entries.size(); ++i) {
      std::cerr << "Entry " << i << ": ";
      for (const auto &key : entries[i].first) {
        std::cerr << key.ToString() << " ";
      }
      std::cerr << std::endl;
    }
  }
  
  // 排序
  TupleComparator cmp(order_bys);
  std::sort(entries.begin(), entries.end(), cmp);
  
  // 排序后：显示结果
  std::cerr << "\n=== After Sorting ===" << std::endl;
  std::cerr << "First 10 entries (should be DESC order for colB):" << std::endl;
  for (size_t i = 0; i < std::min(size_t(10), entries.size()); ++i) {
    std::cerr << "Entry " << i << ": ";
    for (const auto &key : entries[i].first) {
      std::cerr << key.ToString() << " ";
    }
    // 修复：添加 & 操作符
    std::cerr << " | Full tuple: " << entries[i].second.ToString(&child_executor_->GetOutputSchema()) << std::endl;
  }
  
  // 将排序结果存储到单个运行中
   if (!entries.empty()) {
    page_id_t page_id = bpm->NewPage();
    if (page_id == INVALID_PAGE_ID) {
      throw Exception("Cannot allocate page for sorted data");
    }
    
    auto guard_opt = bpm->CheckedWritePage(page_id);
    if (!guard_opt.has_value()) {
      throw Exception("Cannot get write guard for page");
    }
    
    std::optional<WritePageGuard> guard = std::move(guard_opt.value());
    auto sort_page = reinterpret_cast<SortPage *>(guard->GetDataMut());
    new (sort_page) SortPage();
    
    std::vector<page_id_t> pages{page_id};
    
    // 写入排序后的元组并验证
    std::cerr << "\n=== Writing to SortPage ===" << std::endl;
    for (size_t idx = 0; idx < entries.size(); ++idx) {
      const auto &entry = entries[idx];
      
      if (!sort_page->CanAddTuple(entry.second)) {
        // 当前页面已满，创建新页面
        guard = std::nullopt;
        
        page_id = bpm->NewPage();
        if (page_id == INVALID_PAGE_ID) {
          throw Exception("Cannot allocate new page");
        }
        
        guard_opt = bpm->CheckedWritePage(page_id);
        guard = std::move(guard_opt.value());
        sort_page = reinterpret_cast<SortPage *>(guard->GetDataMut());
        new (sort_page) SortPage();
        pages.push_back(page_id);
      }
      
      // 写入前的元组信息
      if (idx < 5) {
        std::cerr << "Writing tuple " << idx << ": " 
                  << entry.second.ToString(&child_executor_->GetOutputSchema()) << std::endl;
      }
      
      sort_page->WriteTuple(entry.second, child_executor_->GetOutputSchema());
      
      // 立即验证写入结果
      if (idx < 5) {
        size_t written_count = sort_page->GetTupleCount();
        if (written_count > 0) {
          Tuple verify_tuple = sort_page->ReadTuple(written_count - 1, child_executor_->GetOutputSchema());
          std::cerr << "Verified tuple " << idx << ": " 
                    << verify_tuple.ToString(&child_executor_->GetOutputSchema()) << std::endl;
        }
      }
    }
    
    runs_.emplace_back(std::move(pages), bpm);
    
    // 修复：确保传递正确的 Schema 引用
    const Schema &output_schema = child_executor_->GetOutputSchema();
    guard = std::nullopt;
    // 验证从 MergeSortRun 读取的数据
    std::cerr << "\n=== Verifying MergeSortRun (Fixed) ===" << std::endl;
    auto verify_iter = runs_[0].Begin(output_schema);

    auto verify_end = runs_[0].End(output_schema);
    
    size_t count = 0;
    while (verify_iter != verify_end && count < 10) {
      Tuple stored_tuple = *verify_iter;
      std::cerr << "MergeSortRun tuple " << count << ": " 
                << stored_tuple.ToString(&output_schema) << std::endl;
      ++verify_iter;
      ++count;
    }
    
    // 准备输出迭代器
    run_iterators_.push_back(runs_[0].Begin(output_schema));
  }
  
  initialized_ = true;
}

template <size_t K>
auto ExternalMergeSortExecutor<K>::Next(Tuple *tuple, RID *rid) -> bool {
  if (!initialized_) {
    Init();
  }
  
  if (runs_.empty() || run_iterators_.empty()) {
    return false;
  }
  
  const Schema &output_schema = child_executor_->GetOutputSchema();
  auto &iter = run_iterators_[0];
  
  if (iter == runs_[0].End(output_schema)) {
    return false;
  }
  
  *tuple = *iter;
  *rid = RID{};

  // 添加调试：输出前几个返回的元组
  static size_t output_count = 0;
  if (output_count < 5) {
    std::cerr << "Next() returning tuple " << output_count << ": " 
              << tuple->ToString(&output_schema) << std::endl;
  }
  ++output_count;
  
  ++iter;
  return true;
}

template class ExternalMergeSortExecutor<2>;

}  // namespace bustub