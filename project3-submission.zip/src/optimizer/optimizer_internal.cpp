//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// optimizer_internal.cpp
//
// Identification: src/optimizer/optimizer_internal.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

namespace bustub {

void OptimizerHelperFunction() {}

}  // namespace bustub
