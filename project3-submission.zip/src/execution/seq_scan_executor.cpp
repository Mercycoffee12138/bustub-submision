//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seq_scan_executor.cpp
//
// Identification: src/execution/seq_scan_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/seq_scan_executor.h"

namespace bustub {

/**
 * Construct a new SeqScanExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The sequential scan plan to be executed
 */
SeqScanExecutor::SeqScanExecutor(ExecutorContext *exec_ctx, const SeqScanPlanNode *plan) : AbstractExecutor(exec_ctx) {
    plan_=plan;
}

/** Initialize the sequential scan */
void SeqScanExecutor::Init() {
  table_info_ = GetExecutorContext()->GetCatalog()->GetTable(plan_->GetTableOid()).get();
  table_heap_ = table_info_->table_.get();
  auto iter = table_heap_->MakeIterator();
  // 开始遍历这个table_heap
  rids_.clear();
  while (!iter.IsEnd()) {
    rids_.push_back(iter.GetRID());
    ++iter;
  }
  iter_start_ = rids_.begin();
}

/**
 * Yield the next tuple from the sequential scan.
 * @param[out] tuple The next tuple produced by the scan
 * @param[out] rid The next tuple RID produced by the scan
 * @return `true` if a tuple was produced, `false` if there are no more tuples
 */
auto SeqScanExecutor::Next(Tuple *tuple, RID *rid) -> bool { 
    TupleMeta meta{};
  // auto iter=rids_.begin();    // 得将这个保存为static或者声明为成员变量
  do {
    if (iter_start_ == rids_.end()) {
      return false;
    }
    meta = table_heap_->GetTupleMeta(*iter_start_);
    if (!meta.is_deleted_) {  // 这个tuple是有效的
      *tuple = table_heap_->GetTuple(*iter_start_).second;
      *rid = *iter_start_;
    }
    ++iter_start_;
  } while (meta.is_deleted_ || (plan_->filter_predicate_ != nullptr &&
                                !plan_->filter_predicate_->Evaluate(tuple, table_info_->schema_).GetAs<bool>()));
  return true;
 }

}  // namespace bustub
