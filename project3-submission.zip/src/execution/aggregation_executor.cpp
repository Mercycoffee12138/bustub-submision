//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// aggregation_executor.cpp
//
// Identification: src/execution/aggregation_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <cstdint>
#include <memory>
#include <utility>
#include <vector>

#include "common/rid.h"
#include "execution/executors/aggregation_executor.h"
#include "execution/plans/aggregation_plan.h"
#include "storage/table/tuple.h"
#include "type/type_id.h"
#include "type/value.h"

namespace bustub {

/**
 * Construct a new AggregationExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The insert plan to be executed
 * @param child_executor The child executor from which inserted tuples are pulled (may be `nullptr`)
 */
AggregationExecutor::AggregationExecutor(ExecutorContext *exec_ctx, const AggregationPlanNode *plan,
                                         std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      child_executor_(std::move(child_executor)),
      aht_(plan->GetAggregates(), plan->GetAggregateTypes()),
      aht_iterator_(aht_.Begin()) {
  // aht_ = SimpleAggregationHashTable(plan->GetAggregates(), plan->GetAggregateTypes());  // 赋值操作有问题
}

/** Initialize the aggregation */
void AggregationExecutor::Init() {
  std::cout << plan_->ToString() << std::endl;
  child_executor_->Init();
  Tuple child_tuple{};
  RID child_rid{};
  auto group_bys = plan_->group_bys_;
  auto group_aggrs = plan_->aggregates_;
  auto aggrs_types = plan_->agg_types_;
  // 从child_exec获得元组, 并进行聚合
  aht_.Clear();
  while (child_executor_->Next(&child_tuple, &child_rid)) {
    auto aggr_key = MakeAggregateKey(&child_tuple);
    AggregateValue aggr_val = MakeAggregateValue(&child_tuple);
    aht_.InsertCombine(aggr_key, aggr_val);
  }  // 现在所有的元组都已经在aht_内了

  if (aht_.Size() == 0 && GetOutputSchema().GetColumnCount() == 1) {// 空的哈希表也要初始化一遍
    aht_.InsertEmptyCombine();
  }
  aht_iterator_ = aht_.Begin();  // 必须重新初始化一遍
}

/**
 * Yield the next tuple from the insert.
 * @param[out] tuple The next tuple produced by the aggregation
 * @param[out] rid The next tuple RID produced by the aggregation
 * @return `true` if a tuple was produced, `false` if there are no more tuples
 */
auto AggregationExecutor::Next(Tuple *tuple, RID *rid) -> bool { 
    if(aht_iterator_==aht_.End()){
        return false;
    }

    auto aggr_key=aht_iterator_.Key();
    auto aggr_value=aht_iterator_.Val();
    std::vector<Value> result;
    // group by也要生成一个新的列
    for(auto & elem:aggr_key.group_bys_){
        result.emplace_back(elem);
    }
    // 把aggregates_对应的值都取出来形成value集合
    for(auto & elem:aggr_value.aggregates_){
        result.emplace_back(elem);
    }
    *tuple=Tuple(result,&GetOutputSchema());
    *rid=tuple->GetRid();
    ++aht_iterator_;
    return true;
}
/** Do not use or remove this function, otherwise you will get zero points. */
auto AggregationExecutor::GetChildExecutor() const -> const AbstractExecutor * { return child_executor_.get(); }

}  // namespace bustub
