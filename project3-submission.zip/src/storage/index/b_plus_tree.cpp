//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree.cpp
//
// Identification: src/storage/index/b_plus_tree.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "storage/index/b_plus_tree.h"
#include "storage/index/b_plus_tree_debug.h"

namespace bustub {

INDEX_TEMPLATE_ARGUMENTS
std::mutex BPLUSTREE_TYPE::global_insert_mutex_;

INDEX_TEMPLATE_ARGUMENTS
std::mutex BPLUSTREE_TYPE::global_remove_mutex_;

INDEX_TEMPLATE_ARGUMENTS
std::mutex BPLUSTREE_TYPE::global_tree_mutex_;

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetLeafPage(const KeyType &key, Context &ctx) ->const LeafPage* {
  // 获取根页面 ID
  page_id_t root_page_id = GetRootPageId();
  if (root_page_id == INVALID_PAGE_ID) {
    // 如果根页面无效，说明树为空
    return nullptr;
  }
  
  // 将根页面 ID 保存在上下文中
  ctx.root_page_id_ = root_page_id;
  
  // 从根页面开始读取
  ReadPageGuard current_guard = bpm_->ReadPage(root_page_id);
  auto current_page = current_guard.As<BPlusTreePage>();
  
  // 遍历 B+ 树，直到找到叶节点
  while (!current_page->IsLeafPage()) {
    auto internal_page = current_guard.template As<InternalPage>();
    
    // 使用 KeyIndex 找到键所在的位置
    // 在内部节点中，找到第一个大于等于key的键的位置
    int index = internal_page->KeyIndex(key, comparator_);
    
    // 获取对应的子节点页面ID
    // 因为内部节点的key[i]指向的是大于等于key[i]的子树
    // 所以我们需要的是index-1位置的指针
    page_id_t child_page_id = internal_page->ValueAt(index - 1);
    
    // 处理 std::optional 返回值
    auto child_guard_opt = bpm_->CheckedReadPage(child_page_id);
    if (!child_guard_opt.has_value()) {
      return nullptr;  // 无法读取页面
    }
    
    // 将当前页面的读锁存入上下文，以便后续释放
    ctx.read_set_.push_back(std::move(current_guard));
    
    // 更新当前节点为子节点
    current_guard = std::move(*child_guard_opt);
    current_page = current_guard.As<BPlusTreePage>();
  }
  
  // 当前页面是叶节点，将其转换为LeafPage类型
  auto leaf_page = current_guard.template As<LeafPage>();
  
  // 将叶节点的读锁存入上下文，以便后续释放
  ctx.read_set_.push_back(std::move(current_guard));
  
  // 返回指向叶页面的指针
  return leaf_page;
}

INDEX_TEMPLATE_ARGUMENTS
BPLUSTREE_TYPE::BPlusTree(std::string name, page_id_t header_page_id, BufferPoolManager *buffer_pool_manager,
                          const KeyComparator &comparator, int leaf_max_size, int internal_max_size)
    : index_name_(std::move(name)),
      bpm_(buffer_pool_manager),
      comparator_(std::move(comparator)),
      leaf_max_size_(leaf_max_size),
      internal_max_size_(internal_max_size),
      header_page_id_(header_page_id) {
  WritePageGuard guard = bpm_->WritePage(header_page_id_);
  auto root_page = guard.AsMut<BPlusTreeHeaderPage>();
  root_page->root_page_id_ = INVALID_PAGE_ID;
}

/**
 * @brief Helper function to decide whether current b+tree is empty
 * @return Returns true if this B+ tree has no keys and values.
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::IsEmpty() const -> bool { 
  // 读取头页面获取根页面ID
  ReadPageGuard guard = bpm_->ReadPage(header_page_id_);
  auto header_page = guard.As<BPlusTreeHeaderPage>();
  return header_page->root_page_id_ == INVALID_PAGE_ID;
 }

/*****************************************************************************
 * SEARCH
 *****************************************************************************/
/**
 * @brief Return the only value that associated with input key
 *
 * This method is used for point query
 *
 * @param key input key
 * @param[out] result vector that stores the only value that associated with input key, if the value exists
 * @return : true means key exists
 */


 INDEX_TEMPLATE_ARGUMENTS
 auto BPLUSTREE_TYPE::GetValue(const KeyType &key, std::vector<ValueType> *result) -> bool {
   // 创建上下文对象，用于跟踪访问的页面
   Context ctx;
 
   // 获取根页面 ID
   //std::cout << "Searching for key: " << key.ToString() << std::endl;
   page_id_t root_page_id = GetRootPageId();
   //std::cout << "Root page ID: " << root_page_id << std::endl;
   if (root_page_id == INVALID_PAGE_ID) {
     // 如果根页面无效，说明树为空
     return false;
   }
   
   // 锁定头页面，确保根页面ID在查询过程中不会变化(并发控制时更改)
   ctx.root_page_id_ = root_page_id;

   // 从根页面开始查找目标叶节点
   ReadPageGuard current_guard = bpm_->ReadPage(root_page_id);
   auto current_page = current_guard.As<BPlusTreePage>();
   //std::cout << "Is leaf page: " << current_page->IsLeafPage() << std::endl;
 
   // 遍历 B+ 树，直到找到叶节点
   while (!current_page->IsLeafPage()) {
     auto internal_page = current_guard.template As<InternalPage>();  // 使用在 BPlusTree 类中定义的类型别名
     // 使用 KeyIndex 找到第一个大于等于key的位置
     int index = internal_page->KeyIndex(key, comparator_);
     // 获取对应的子节点页面ID (使用index-1是因为要获取前一个位置的子节点)
     page_id_t child_page_id = internal_page->ValueAt( index - 1);
     
     // 处理 std::optional 返回值
     auto child_guard_opt = bpm_->CheckedReadPage(child_page_id);
     if (!child_guard_opt.has_value()) {
       return false;  // 无法读取页面
     }

      // 将子节点的读锁存入上下文，同时将当前锁移入上下文以便后续释放
    ctx.read_set_.push_back(std::move(current_guard));
    
    // 更新当前节点为子节点
    current_guard = std::move(*child_guard_opt);
    current_page = current_guard.As<BPlusTreePage>();
    //std::cout << "Current page ID: " << current_page->GetPageId() << std::endl;

     // 安全的时机：确认是安全节点时释放祖先节点
    // 安全节点：非满节点(插入时)或超过半满节点(删除时)
    // 对于查询操作，我们可以在获取子节点后立即释放所有祖先节点
    if (ctx.read_set_.size() >= 2) {
      // 保留最近的父节点，以防回溯需要
      ReadPageGuard parent_guard = std::move(ctx.read_set_.back());
      ctx.read_set_.pop_back();
      
      // 释放所有更早的祖先节点
      ctx.read_set_.clear();
      
      // 如果需要，可以保留父节点以便后续使用
      if (parent_guard.GetPageId() != INVALID_PAGE_ID) {
        ctx.read_set_.push_back(std::move(parent_guard));
      }
    }
   }
 
   // 当前页面是叶节点，查找目标键
   auto leaf_page = current_guard.template As<LeafPage>();  // 使用在 BPlusTree 类中定义的类型别名
   //std::cout << "Leaf page size: " << leaf_page->GetSize() << std::endl;
   for (int i = 0; i < leaf_page->GetSize(); i++) {
     /*std::cout << "Key at " << i << ": " << leaf_page->KeyAt(i).ToString() 
               << ", RID: (" << leaf_page->ValueAt(i).GetPageId() 
               << "," << leaf_page->ValueAt(i).GetSlotNum() << ")" << std::endl;*/
   }

   // 在叶子节点中搜索目标键
   int index = leaf_page->KeyIndex(key, comparator_);
   bool found = false;

   if (index < leaf_page->GetSize() && comparator_(leaf_page->KeyAt(index), key) == 0) {
     // 找到目标键，将对应的值存入 result
 
     //调试输出信息
     /*std::cout << "Found key: " << leaf_page->KeyAt(index).ToString() << ", RID: page=" 
           << leaf_page->ValueAt(index).GetPageId() << ", slot=" << leaf_page->ValueAt(index).GetSlotNum() << std::endl;*/
     
     result->push_back(leaf_page->ValueAt(index));
     found = true;
   }
 
   // 将最后的锁移入上下文以便自动释放
  ctx.read_set_.push_back(std::move(current_guard));

   // 未找到目标键
   //std::cout << "Key not found: " << key.ToString() << std::endl;
   return found;
 }


/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/**
 * @brief Insert constant key & value pair into b+ tree
 *
 * if current tree is empty, start new tree, update root page id and insert
 * entry, otherwise insert into leaf page.
 *
 * @param key the key to insert
 * @param value the value associated with key
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
 INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::InsertIntoParent(BPlusTreePage *left_page, const KeyType &key, BPlusTreePage *right_page, Context *ctx) -> bool {
  // 如果left_page是根节点，需要创建新的根节点
  if (ctx->write_set_.size() == 2) {
    // 获取头页面的写锁(如果还没有获取)
    if (!ctx->header_page_.has_value()) {
      ctx->header_page_ = bpm_->WritePage(header_page_id_);
    }

    // 创建新的根节点（内部节点）
    page_id_t new_page_id = bpm_->NewPage();
    if (new_page_id == INVALID_PAGE_ID) {
      return false;  // 创建新页面失败
    }
    
    WritePageGuard new_root_guard = bpm_->WritePage(new_page_id);
    auto new_root = new_root_guard.template AsMut<InternalPage>();
    
    new_root->Init(internal_max_size_);
    new_root->SetPageId(new_page_id);
    new_root->SetParentPageId(INVALID_PAGE_ID);
    
    // 设置新根节点的键值对
    new_root->SetKeyAt(1, key);
    new_root->SetValueAt(0, left_page->GetPageId());
    new_root->SetValueAt(1, right_page->GetPageId());
    new_root->SetSize(2);  // 内部节点大小包括第一个无效键

    auto new_root_id=new_root->GetPageId();
    
    // 更新子节点的父节点指针
    left_page->SetParentPageId(new_page_id);
    right_page->SetParentPageId(new_page_id);
    
    // 更新头页面中的根节点ID（并发控制时更改）
    auto header_page = ctx->header_page_.value().AsMut<BPlusTreeHeaderPage>();
    header_page->root_page_id_ = new_root_id;
    
    // 更新上下文中的根节点ID
    ctx->root_page_id_ = new_root_id;
    
    // 释放头页面锁
    ctx->header_page_.reset();

    //std::cout << "创建新根节点: " << new_root_id << std::endl;

    ctx->write_set_.clear();//清空锁集合
    
    return true;
  }
  
  // 找到父节点并插入新的键值对（在并发控制下获取父节点的情况被重构了）
  //std::cout<<"这是在并发控制时更改的节点分裂父节点获取过程"<<std::endl;
  page_id_t parent_page_id = left_page->GetParentPageId();
  //std::cout<<"parent_page_id :"<<parent_page_id<<std::endl;
  
  // 从写集合中找到父节点，或者获取父节点的写锁
  WritePageGuard parent_guard;
  BPlusTreePage *parent_page = nullptr;

  // 寻找父节点
  auto it = std::find_if(ctx->write_set_.begin(), ctx->write_set_.end(), 
                       [parent_page_id](const WritePageGuard& guard) {
                         return guard.GetPageId() == parent_page_id;
                       });
  
  if (it != ctx->write_set_.end()) {
    // 找到了父节点
    WritePageGuard temp_guard = std::move(*it);
    parent_page = temp_guard.AsMut<BPlusTreePage>();
    
    // 从写集合中移除父节点
    ctx->write_set_.erase(it);
    
    parent_guard = std::move(temp_guard);
  } 
  else {
    // 没找到，获取新锁
    auto parent_guard_opt = bpm_->CheckedWritePage(parent_page_id);
    if (!parent_guard_opt.has_value()) {
      //std::cout << "没有找到父节点的写锁" << std::endl;
      return false;
    }
    parent_guard = std::move(parent_guard_opt.value());
    parent_page = parent_guard.AsMut<BPlusTreePage>();
  }
  //std::cout<<"并发控制时更改的节点分裂父节点获取完成"<<std::endl;
  
  auto parent = reinterpret_cast<InternalPage *>(parent_page);
  //std::cout<<"parent_page_id<<"<<parent->GetPageId()<<std::endl;
  //std::cout<<"parent_page_size(1) :"<<parent->GetSize()<<std::endl;
  
  // 设置右子节点的父节点指针
  right_page->SetParentPageId(parent->GetPageId());
  //std::cout<<"right_page_id :"<<right_page->GetPageId()<<std::endl;
  //std::cout<<"left_page_id :"<<left_page->GetPageId()<<std::endl;
  
  // 找到left_page在父节点中的位置
  int left_index = -1;
  for (int i = 0; i < parent->GetSize(); i++) {
    if (parent->ValueAt(i) == left_page->GetPageId()) {
      left_index = i;
      break;
    }
  }

  
  // 父节点是否满了？
  //std::cout<<"parent_size(2) :"<<parent->GetSize()<<std::endl;
  //std::cout<<"parent_max_size :"<<parent->GetMaxSize()<<std::endl;
  if (parent->GetSize() < parent->GetMaxSize()) {
    // 父节点未满，直接插入
    //std::cout<<"父节点没有满,直接插入"<<std::endl;
    // 从插入位置开始，将所有键值对后移一位
    for (int i = parent->GetSize(); i > left_index + 1; i--) {
      parent->SetKeyAt(i, parent->KeyAt(i - 1));
      parent->SetValueAt(i, parent->ValueAt(i - 1));
    }
    
    // 在插入位置放入新的键值对
    parent->SetKeyAt(left_index + 1, key);
    parent->SetValueAt(left_index + 1, right_page->GetPageId());
    parent->SetSize(parent->GetSize() + 1);
    
    // 将父节点guard重新添加到write_set_
    ctx->write_set_.push_back(std::move(parent_guard));
    
    //std::cout << "父节点插入成功，无需分裂" << std::endl;

    return true;
  }
  
  // 父节点已满，需要分裂
  // 创建一个新的内部节点
 // std::cout << "父节点已满，需要分裂" << std::endl;
  page_id_t new_internal_id = bpm_->NewPage();
  if (new_internal_id == INVALID_PAGE_ID) {
    return false;  // 创建新页面失败
  }
  //std::cout<<"获取internal节点的锁"<<std::endl;
  //父节点分裂出来的节点
  WritePageGuard new_internal_guard = bpm_->WritePage(new_internal_id);
  auto new_internal = new_internal_guard.template AsMut<InternalPage>();
  
  new_internal->Init(internal_max_size_);
  new_internal->SetPageId(new_internal_id);
  new_internal->SetParentPageId(parent->GetParentPageId());  // 新内部节点的父节点与原父节点相同
  

  // 临时数组存储所有键值对(包含新键值对)
  std::vector<KeyType> temp_keys(internal_max_size_ + 1);
  std::vector<page_id_t> temp_values(internal_max_size_ + 1);
  
  // 复制父节点的值到临时数组
  for (int i = 0; i < parent->GetSize(); i++) {
    if (i > 0) {
      temp_keys[i] = parent->KeyAt(i);
    }
    temp_values[i] = parent->ValueAt(i);
  }
  
  // 插入新的键值对
  int insert_pos = left_index + 1;
  for (int i = parent->GetSize(); i > insert_pos; i--) {
    temp_keys[i] = temp_keys[i - 1];
    temp_values[i] = temp_values[i - 1];
  }
  temp_keys[insert_pos] = key;
  temp_values[insert_pos] = right_page->GetPageId();
  
  // 计算分裂点(中间位置)以后根据max_size的奇偶判断条件不要改我的，我就是这个思路
  int middle = (internal_max_size_ + 1) / 2;
  // 获取中间键，用于上层索引
  KeyType middle_key = temp_keys[middle];
  if(internal_max_size_%2!=0){
    middle-=1;
    middle_key = temp_keys[middle+1];
  }
    
  // 重新分配键值对
  parent->SetSize(middle+1);  // 原内部节点保留前半部分
  
  // 原内部节点保留前半部分
  for (int i = 0; i <= middle; i++) {
    if (i > 0) {
      parent->SetKeyAt(i, temp_keys[i]);
    }
    parent->SetValueAt(i, temp_values[i]);
  }
  
  
  
  // 新内部节点包含后半部分
  new_internal->SetSize(internal_max_size_ - middle);
  new_internal->SetValueAt(0, temp_values[middle+1]);
  
  for (int i = middle+2 , j = 1; i <= internal_max_size_; i++, j++) {
    new_internal->SetKeyAt(j, temp_keys[i]);
    new_internal->SetValueAt(j, temp_values[i]);
  }
  
  //std::cout<<"加锁,逐个更新子节点的父指针"<<std::endl;
  // 收集所有需要更新父指针的子节点页面ID
  std::vector<page_id_t> child_page_ids;
  for (int i = middle+1; i <= internal_max_size_; i++) {
    child_page_ids.push_back(temp_values[i]);
  }
  
  // 先获取并缓存所有子节点页面的父指针
  std::unordered_map<page_id_t, page_id_t> update_map;
  for (auto child_id : child_page_ids) {
    // 将每个子节点的新父指针存储到map中
    update_map[child_id] = new_internal_id;
  }
  
  // 释放当前持有的锁，避免死锁
  ctx->write_set_.pop_back();
  ctx->write_set_.pop_back();
  
  // 现在执行实际的更新操作
  for (auto child_id : child_page_ids) {
    WritePageGuard child_guard = bpm_->WritePage(child_id);
    auto child_page = child_guard.AsMut<BPlusTreePage>();
    child_page->SetParentPageId(update_map[child_id]);
    // 锁会在本次循环结束时自动释放
  }
  
  // 将父节点guard重新添加到write_set_
  //std::cout<<"parent_guard_id"<<parent_guard.GetPageId()<<std::endl;
  ctx->write_set_.push_back(std::move(parent_guard));
  
  // 将新内部节点的写保护添加到上下文
  //std::cout<<"new_internal_guard_id"<<new_internal_guard.GetPageId()<<std::endl;
  ctx->write_set_.push_back(std::move(new_internal_guard));

  //std::cout << "write_set_大小: " << ctx->write_set_.size() << std::endl;
  
  // 递归处理上一层父节点 - 使用父节点和新内部节点作为子节点
  return InsertIntoParent(parent, middle_key, new_internal, ctx);
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::InsertIntoLeaf(const KeyType &key, const ValueType &value, Context *ctx) -> bool {
  if (ctx->write_set_.empty()) {
    return false; // 错误状态
  }

  // 获取根节点的页面
  BPlusTreePage *curr_page = ctx->write_set_[0].AsMut<BPlusTreePage>();
  
  // 判断根节点是否为叶子节点
  if (curr_page->IsLeafPage()) {
    // 根节点就是叶子节点，直接在其中执行插入操作
    auto leaf_page = ctx->write_set_[0].template AsMut<LeafPage>();
    
    // 找到插入位置：第一个比目标键的值大的键
    int insert_index = leaf_page->KeyIndex(key, comparator_);
    
    // 检查是否是重复键
    if (insert_index < leaf_page->GetSize() && 
        comparator_(leaf_page->KeyAt(insert_index), key) == 0) {
      //std::cout << "Duplicate key found (root is leaf): " << key.ToString() << std::endl;
      return false;  // 重复键不插入
    }
    
    // 叶子节点是否满了？
    if (leaf_page->GetSize() < leaf_page->GetMaxSize()) {
      // 叶节点未满，直接插入
      // 检查是否是重复键
    if (insert_index < leaf_page->GetSize() && 
      comparator_(leaf_page->KeyAt(insert_index), key) == 0) {
        //std::cout << "Duplicate key found (root is leaf): " << key.ToString() << std::endl;
        return false;  // 重复键不插入
      }
      // 从插入位置开始，将所有键值对后移一位
      for (int i = leaf_page->GetSize(); i > insert_index; i--) {
        leaf_page->SetKeyAt(i, leaf_page->KeyAt(i - 1));
        leaf_page->SetValueAt(i, leaf_page->ValueAt(i - 1));
      }
      
      // 在插入位置放入新的键值对
      leaf_page->SetKeyAt(insert_index, key);
      leaf_page->SetValueAt(insert_index, value);
      leaf_page->ChangeSizeBy(1);

      /*std::cout << "插入根节点, content:" << std::endl;
      for (int i = 0; i < leaf_page->GetSize(); i++) {
          std::cout << "Key at " << i << ": " << leaf_page->KeyAt(i).ToString() 
                  << ", RID: (" << leaf_page->ValueAt(i).GetPageId() 
                  << "," << leaf_page->ValueAt(i).GetSlotNum() << ")" << std::endl;
      }*/
      
      return true;
    }
  } 
  else {
    // 根节点是内部节点，需要向下遍历到叶子节点
    //std::cout<<"根节点不是叶子结点"<<std::endl;
    // 从根节点开始，向下遍历到叶子节点
    while (!curr_page->IsLeafPage()) {
      //std::cout<<"开始遍历操作查找"<<std::endl;
      auto internal_page = ctx->write_set_.back().template AsMut<InternalPage>();
      int index = internal_page->KeyIndex(key, comparator_);
      page_id_t child_page_id = internal_page->ValueAt(index - 1);

      //std::cout<<"获取子节点写锁"<<std::endl;
      // 获取子节点写锁(并发控制时增加)
      auto child_guard_opt = bpm_->CheckedWritePage(child_page_id);
      if (!child_guard_opt.has_value()) {
        return false; // 无法获取子节点
      }
      
      auto &child_guard = child_guard_opt.value();
      auto child_page = child_guard.AsMut<BPlusTreePage>();

      // 安全节点判断: 如果子节点不会分裂，可以释放祖先节点的锁
      bool is_safe = child_page->GetSize() < child_page->GetMaxSize()-1;
      
      // 将子节点的写锁放入上下文
      ctx->write_set_.push_back(std::move(child_guard));

      // 如果子节点是安全的，可以释放除父节点外的所有祖先节点锁
      if (is_safe && ctx->write_set_.size() > 2) {
        //std::cout<<"子节点安全,释放除了父节点以外的祖先结点锁"<<std::endl;
        // 保留当前节点和父节点
        WritePageGuard parent_guard = std::move(ctx->write_set_[ctx->write_set_.size() - 2]);
        WritePageGuard current_guard = std::move(ctx->write_set_.back());
        
        // 清空写集合
        ctx->write_set_.clear();
        
        // 重新添加父节点和当前节点
        ctx->write_set_.push_back(std::move(parent_guard));
        ctx->write_set_.push_back(std::move(current_guard));
      }

      curr_page = child_page;
    }
   // std::cout<<"已经到达叶子节点"<<std::endl;
    //std::cout<<"当前叶子节点的ID:"<<curr_page->GetPageId()<<std::endl;
    // 现在我们在叶子节点上
    auto leaf_page = ctx->write_set_.back().template AsMut<LeafPage>();
    
    // 找到插入位置
    int insert_index = leaf_page->KeyIndex(key, comparator_);
    
    // 检查是否是重复键
    if (insert_index < leaf_page->GetSize() && 
        comparator_(leaf_page->KeyAt(insert_index), key) == 0) {
      //std::cout << "Duplicate key found (after traversal): " << key.ToString() << std::endl;
      return false;  // 重复键不插入
    }
    
    // 叶子节点是否满了？
    if (leaf_page->GetSize() < leaf_page->GetMaxSize()) {
      if (insert_index < leaf_page->GetSize() && 
        comparator_(leaf_page->KeyAt(insert_index), key) == 0) {
      //std::cout << "Duplicate key found (root is leaf): " << key.ToString() << std::endl;
      return false;  // 重复键不插入
    }
      // 叶节点未满，直接插入
      //std::cout<<"叶子结点未满,直接开始插入"<<std::endl;
      // 从插入位置开始，将所有键值对后移一位
      for (int i = leaf_page->GetSize(); i > insert_index; i--) {
        leaf_page->SetKeyAt(i, leaf_page->KeyAt(i - 1));
        leaf_page->SetValueAt(i, leaf_page->ValueAt(i - 1));
      }
      
      // 在插入位置放入新的键值对
      leaf_page->SetKeyAt(insert_index, key);
      leaf_page->SetValueAt(insert_index, value);
      leaf_page->ChangeSizeBy(1);

      // 在这里添加验证
      /*std::cout << "插入叶节点, content:" << std::endl;
      for (int i = 0; i < leaf_page->GetSize(); i++) {
          std::cout << "Key at " << i << ": " << leaf_page->KeyAt(i).ToString() 
                  << ", RID: (" << leaf_page->ValueAt(i).GetPageId() 
                  << "," << leaf_page->ValueAt(i).GetSlotNum() << ")" << std::endl;
      }*/
      
      return true;
    }
  }
  
  // 到这里，说明叶节点已满，需要分裂
  // 获取当前叶节点
  
  auto leaf_page = ctx->write_set_.back().template AsMut<LeafPage>();
  //std::cout<<"leaf_page_size:"<<leaf_page->GetSize()<<std::endl;
  //std::cout<<"leaf_page_maxn_size"<<leaf_page->GetMaxSize()<<std::endl;

  // 创建一个新的叶节点
  page_id_t new_page_id = bpm_->NewPage();
  if (new_page_id == INVALID_PAGE_ID) {
    return false;  // 无法创建新页面
  }
  
  WritePageGuard new_leaf_guard = bpm_->WritePage(new_page_id);
  auto new_leaf = new_leaf_guard.template AsMut<LeafPage>();
  
  new_leaf->Init(leaf_max_size_);
  new_leaf->SetPageId(new_page_id);
  
  // 设置链表指针
  new_leaf->SetNextPageId(leaf_page->GetNextPageId());
  leaf_page->SetNextPageId(new_page_id);
  
  // 计算分裂点(中间位置)
  int middle = (leaf_max_size_ + 1) / 2;
  if(leaf_max_size_%2!=0){
    middle-=1;
  }
  int insert_index = leaf_page->KeyIndex(key, comparator_);
  if (insert_index < leaf_page->GetSize() && 
  comparator_(leaf_page->KeyAt(insert_index), key) == 0) {
    //std::cout << "Duplicate key found (root is leaf): " << key.ToString() << std::endl;
    return false;  // 重复键不插入
    }

  int orig_size = leaf_page->GetSize();
  
  // 简化的分裂逻辑：先复制所有原始键值到临时数组
  std::vector<KeyType> temp_keys(leaf_max_size_ + 1);
  std::vector<ValueType> temp_rids(leaf_max_size_ + 1);

  // 复制原始键值对到临时数组
  for (int i = 0; i < orig_size; i++) {
    temp_keys[i] = leaf_page->KeyAt(i);
    temp_rids[i] = leaf_page->ValueAt(i);
  }

  // 在插入位置加入新键值对
  for (int i = orig_size; i > insert_index; i--) {
    temp_keys[i] = temp_keys[i-1];
    temp_rids[i] = temp_rids[i-1];
  }
  temp_keys[insert_index] = key;
  temp_rids[insert_index] = value;

  // 重新分配到两个叶子节点
  for (int i = 0; i <= middle; i++) {
    leaf_page->SetKeyAt(i, temp_keys[i]);
    leaf_page->SetValueAt(i, temp_rids[i]);
  }
  leaf_page->SetSize(middle+1);

  for (int i = 0, j = middle+1; j <= orig_size; i++, j++) {
    new_leaf->SetKeyAt(i, temp_keys[j]);
    new_leaf->SetValueAt(i, temp_rids[j]);
  }
  new_leaf->SetSize(orig_size - middle );
  
  // 获取原来叶节点的最后一个键，用于上层索引
  KeyType middle_key = leaf_page->KeyAt(leaf_page->GetSize() - 1);
  
  
  //std::cout << "分裂, original leaf content:" << std::endl;
  /*for (int i = 0; i < leaf_page->GetSize(); i++) {
      std::cout << "Key at " << i << ": " << leaf_page->KeyAt(i).ToString() 
                << ", RID: (" << leaf_page->ValueAt(i).GetPageId() 
                << "," << leaf_page->ValueAt(i).GetSlotNum() << ")" << std::endl;
  }

  //std::cout << "分裂, new leaf content:" << std::endl;
  for (int i = 0; i < new_leaf->GetSize(); i++) {
      std::cout << "Key at " << i << ": " << new_leaf->KeyAt(i).ToString() 
                << ", RID: (" << new_leaf->ValueAt(i).GetPageId() 
                << "," << new_leaf->ValueAt(i).GetSlotNum() << ")" << std::endl;
  }*/

  // 将新叶节点的写保护添加到上下文
  ctx->write_set_.push_back(std::move(new_leaf_guard));
  //std::cout<<"write_set_size "<<ctx->write_set_.size()<<std::endl;

  //std::cout<<"leaf_page_id :"<<leaf_page->GetPageId()<<std::endl;
  //std::cout<<"new_leaf_page_id :"<<new_leaf->GetPageId()<<std::endl;
  
  // 处理父节点
  return InsertIntoParent(leaf_page, middle_key, new_leaf, ctx);
}


INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Insert(const KeyType &target_key, const ValueType &target_value) -> bool {
  // 日志记录
  std::lock_guard<std::mutex> global_lock(global_tree_mutex_);
  /*std::cout << "开始插入: key=" << target_key.ToString() 
            << ", value=(" << target_value.GetPageId() 
            << "," << target_value.GetSlotNum() << ")" << std::endl;*/
  // 检查是否是最近插入的键
  /*{
    std::lock_guard<std::mutex> guard(recent_keys_mutex_);
    // 将结果转换为std::string
    std::string key_str = std::to_string(target_key.ToString());
    if (recent_inserted_keys_.find(key_str) != recent_inserted_keys_.end()) {
      std::cout << "已经最近插入过此键: " << target_key.ToString() << std::endl;
      return false;
    }
    
    // 标记为正在插入（在插入前就标记）
    recent_inserted_keys_.insert(key_str);
  }*/
  // 创建上下文对象（并发控制处理）
  Context ctx;

  // 特殊情况：空树
  if (IsEmpty()) {
    // 获取头页面的写锁，用于更新根节点指针
    ctx.header_page_ = bpm_->WritePage(header_page_id_);

    return CreateNewRoot(target_key, target_value,&ctx);
  }
  // 正常情况：非空树
  
  // 获取根节点ID
  page_id_t root_id = GetRootPageId();
  ctx.root_page_id_ = root_id;
  //std::cout << "当前根节点ID: " << root_id << std::endl;

  // 获取根节点并开始操作
  WritePageGuard root_guard = bpm_->WritePage(root_id);
  //auto root_page = root_guard.AsMut<BPlusTreePage>();
  
  // 将根节点写锁放入上下文
  ctx.write_set_.push_back(std::move(root_guard));
  //std::cout<<"开始进行叶结点的插入"<<std::endl;
  // 执行叶子节点插入
  return InsertIntoLeaf(target_key, target_value, &ctx);
}

// 辅助函数：创建新的根节点（树为空时使用）
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::CreateNewRoot(const KeyType &key, const ValueType &value, Context *ctx) -> bool {
  // 分配新页面
  page_id_t new_root_id = bpm_->NewPage();
  if (new_root_id == INVALID_PAGE_ID) {
    return false; // 页面分配失败
  }
  
  // 初始化新的根节点（叶子页）
  auto guard = bpm_->WritePage(new_root_id);
  auto root_leaf = guard.AsMut<LeafPage>();
  
  // 设置页面属性
  root_leaf->Init(leaf_max_size_);
  root_leaf->SetPageId(new_root_id);
  root_leaf->SetParentPageId(INVALID_PAGE_ID);
  
  // 添加第一个键值对
  root_leaf->SetKeyAt(0, key);
  root_leaf->SetValueAt(0, value);
  root_leaf->SetSize(1);
  
  // 使用上下文中已经获取的头页面锁，而不是重新获取（并发控制修改）
  if (!ctx->header_page_.has_value()) {
    return false; // 这种情况不应该发生，因为Insert已经获取了锁
  }
  auto header = ctx->header_page_.value().AsMut<BPlusTreeHeaderPage>();
  header->root_page_id_ = new_root_id;
  
  return true;
}


/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/**
 * @brief Delete key & value pair associated with input key
 * If current tree is empty, return immediately.
 * If not, User needs to first find the right leaf page as deletion target, then
 * delete entry from leaf page. Remember to deal with redistribute or merge if
 * necessary.
 *
 * @param key input key
 */
 INDEX_TEMPLATE_ARGUMENTS
 void BPLUSTREE_TYPE::Remove(const KeyType &key) {
  // 添加全局删除锁，确保一次只有一个线程执行删除操作
  //std::lock_guard<std::mutex> global_lock(global_tree_mutex_);
   // 如果树为空，直接返回
   if (IsEmpty()) {
     return;
   }
   // 创建上下文对象记录访问页面
   Context ctx;
   // 获取根页面ID
   page_id_t root_id = GetRootPageId();
   ctx.root_page_id_ = root_id;
   // 获取根节点的写锁
   WritePageGuard root_guard = bpm_->WritePage(root_id);
   ctx.write_set_.push_back(std::move(root_guard));
   // 调用辅助函数查找并删除键
   bool deleted = FindAndRemoveFromLeaf(key, &ctx);
   // 检查根节点是否需要调整（可能为空或只有一个子节点）
   if (deleted && !ctx.write_set_.empty()) {
    //std::cout<<ctx.write_set_.empty()<<std::endl;
    //std::cout << "这个是在remove主函数进去调整树结构的"<< std::endl;
     AdjustAfterRemove(&ctx);
   }
 }

 INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::FindAndRemoveFromLeaf(const KeyType &key, Context *ctx) -> bool {
  // 打印删除操作开始信息
  //std::cout << "【删除开始】准备删除键: " << key.ToString() << std::endl;
  // 开始时，当前页面是根节点
  BPlusTreePage *curr_page = ctx->write_set_[0].AsMut<BPlusTreePage>();
  

  // 向下遍历树，找到包含key的叶节点
  while (!curr_page->IsLeafPage()) {
    auto internal_page = reinterpret_cast<InternalPage *>(curr_page);
    
    // 使用KeyIndex查找第一个大于等于key的位置，与GetValue保持一致
    int index = internal_page->KeyIndex(key, comparator_);
    //std::cout<<"当前索引: "<<index<<std::endl;
    // 确保索引不会越界
    if (index >= internal_page->GetSize()) {
      index = internal_page->GetSize() - 1;
    } else if (index > 0 && comparator_(key, internal_page->KeyAt(index)) <= 0) {
      // 如果key小于等于index位置的键，使用前一个子节点
      index--;
    }
    
    // 获取子节点页面ID
    page_id_t child_page_id = internal_page->ValueAt(index);
    
    // 获取子节点的写锁
    WritePageGuard child_guard = bpm_->WritePage(child_page_id);
    ctx->write_set_.push_back(std::move(child_guard));
    
    // 移动到子节点
    curr_page = ctx->write_set_.back().AsMut<BPlusTreePage>();
  }
  
  // 现在我们在叶节点上
  auto leaf_page = reinterpret_cast<LeafPage *>(curr_page);
  
  // 查找key在叶节点中的位置
  int index = leaf_page->KeyIndex(key, comparator_);
  
  // 如果key不存在，返回false
  if (index >= leaf_page->GetSize() || comparator_(leaf_page->KeyAt(index), key) != 0) {
    //std::cout<<"未找到值"<<std::endl;
    //std::cout << "【删除失败】键: " << key.ToString() << " 不存在于叶节点中" << std::endl;
    return false;
  }
  
  // 删除key-value对，将后面的键值对向前移动
  for (int i = index; i < leaf_page->GetSize() - 1; i++) {
    leaf_page->SetKeyAt(i, leaf_page->KeyAt(i + 1));
    leaf_page->SetValueAt(i, leaf_page->ValueAt(i + 1));
  }
  
  // 在删除前，判断是否是叶节点的第一个或最后一个键
  bool is_first_key = (index == 0);
  bool is_last_key = (index == leaf_page->GetSize() - 1);
  KeyType deleted_key = leaf_page->KeyAt(index);

  // 减少叶节点大小
  leaf_page->SetSize(leaf_page->GetSize() - 1);

  // 如果删除的是边界键，检查并更新内部节点中的分隔键
  if ((is_first_key || is_last_key) && ctx->write_set_.size() > 1) {
    //std::cout << "【删除边界键】检查内部节点分隔键" << std::endl;
    
    // 从叶节点的父节点开始向上检查
    for (size_t i = ctx->write_set_.size() - 2; i > 0; i--) {
      auto parent_page = ctx->write_set_[i].AsMut<InternalPage>();
      
      // 在父节点中查找与删除键匹配的分隔键
      for (int j = 1; j < parent_page->GetSize(); j++) {
        if (comparator_(parent_page->KeyAt(j), deleted_key) == 0) {
          //std::cout << "【更新内部节点】找到需要更新的分隔键: " << deleted_key.ToString() << std::endl;
          
          // 找到当前子树中的替代键（如果删除的是最小键，使用新的最小键，如果是最大键，使用新的最大键）
          KeyType replacement_key;
          if (leaf_page->GetSize() > 0) {
            // 如果是第一个键被删除，用新的第一个键替换
            if (is_first_key) {
              replacement_key = leaf_page->KeyAt(0);
            } 
            // 如果是最后一个键被删除，用新的最后一个键替换
            else if (is_last_key) {
              replacement_key = leaf_page->KeyAt(leaf_page->GetSize() - 1);
            }
            
            //std::cout << "【更新内部节点】替换键为: " << replacement_key.ToString() << std::endl;
            parent_page->SetKeyAt(j, replacement_key);
          } else {
            //std::cout << "【警告】叶节点为空，无法更新分隔键" << std::endl;
          }
          break;
        }
      }
    }
  }

  // 检查是否是根叶节点且为空，这种情况需要特殊处理
  if (ctx->IsRootPage(leaf_page->GetPageId()) && leaf_page->GetSize() == 0) {
    return true;  // 返回true表示需要在Remove函数中调用AdjustAfterRemove
  }

  // 检查叶节点是否低于最小大小，需要调整
  if (leaf_page->GetSize() < leaf_page->GetMinSize()) {
    // 如果不是根节点，需要借或合并
    if (!ctx->IsRootPage(leaf_page->GetPageId())) {
      //std::cout<<leaf_page->GetSize()<<std::endl;
      //std::cout << "【删除后调整】开始调整树结构" << std::endl;
      return true;
    }
  }
  //std::cout << "【删除完成】键: " << key.ToString() <<std::endl;
  //std::cout <<"不需要进行调整"<< std::endl;
  return false;
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::AdjustAfterRemove(Context *ctx) -> bool {
  //std::cout << "【调整】开始调整树结构" << std::endl;
  if (ctx->write_set_.empty()) {
    return true;
  }
  while (!ctx->write_set_.empty()){
  // 获取当前节点
  BPlusTreePage *curr_page = ctx->write_set_.back().AsMut<BPlusTreePage>();
  
  // 特殊情况：如果当前节点是根节点
  if (ctx->IsRootPage(curr_page->GetPageId())) {
    //std::cout<< "【调整】当前节点是根节点" << std::endl;
    // 如果根节点是叶节点且为空，删除这棵树
    if (curr_page->IsLeafPage() && curr_page->GetSize() == 0) {
      // 更新头页面，标记树为空
      WritePageGuard header_guard = bpm_->WritePage(header_page_id_);
      auto header_page = header_guard.AsMut<BPlusTreeHeaderPage>();
      //std::cout << "【调整】更新前根页面ID: " << header_page->root_page_id_ << std::endl;
      header_page->root_page_id_ = INVALID_PAGE_ID;
      //std::cout << "【调整】更新后根页面ID: " << header_page->root_page_id_ << std::endl;
      
      ctx->write_set_.clear();
      // 释放根节点
      bpm_->DeletePage(curr_page->GetPageId());
      return true;
    }

    // 当前节点不是根节点，需要获取父节点
    if (ctx->write_set_.size() < 2) {
      return true;  // 安全检查
    }
    
    
    // 如果根节点是内部节点且只有一个子节点，更新根节点
    if (!curr_page->IsLeafPage() && curr_page->GetSize() == 1) {
      //std::cout << "【调整】根节点是内部节点且只有一个子节点" << std::endl;
      auto internal_page = reinterpret_cast<InternalPage *>(curr_page);
      page_id_t new_root_id = internal_page->ValueAt(0);
      
      // 获取新根节点
      WritePageGuard new_root_guard = bpm_->WritePage(new_root_id);
      auto new_root = new_root_guard.AsMut<BPlusTreePage>();
      // 设置新根节点的父节点为无效
      new_root->SetParentPageId(INVALID_PAGE_ID);
      
      // 更新头页面
      WritePageGuard header_guard = bpm_->WritePage(header_page_id_);
      auto header_page = header_guard.AsMut<BPlusTreeHeaderPage>();
      header_page->root_page_id_ = new_root_id;
      
      // 释放旧根节点
      bpm_->DeletePage(curr_page->GetPageId());
      return true;
    }
    
    // 如果根节点满足最小大小要求，不需要调整
    return true;
  }
  //std::cout << "【调整】当前节点不是根节点" << std::endl;
  // 获取父节点
  if (ctx->write_set_.size() < 2) {
    return true;  // 安全检查
  }
  
  BPlusTreePage *parent_page = ctx->write_set_[ctx->write_set_.size() - 2].AsMut<BPlusTreePage>();
  auto parent = reinterpret_cast<InternalPage *>(parent_page);
  
  // 查找当前节点在父节点中的索引
  int child_index = 0;
  page_id_t curr_page_id = curr_page->GetPageId();
  for (int i = 0; i < parent->GetSize(); i++) {
    if (parent->ValueAt(i) == curr_page_id) {
      child_index = i;
      break;
    }
  }

  // 检查是否可以从左兄弟借键
  if (child_index > 0) {
    page_id_t left_sibling_id = parent->ValueAt(child_index - 1);
    WritePageGuard left_guard = bpm_->WritePage(left_sibling_id);
    BPlusTreePage *left_sibling_page = left_guard.AsMut<BPlusTreePage>();
    //std::cout<<"开始向左兄弟借"<<std::endl;
    if (left_sibling_page->GetSize() > left_sibling_page->GetMinSize()) {
      // 可以从左兄弟借一个键
      if (curr_page->IsLeafPage()) {
        // 当前节点是叶节点
        auto leaf = reinterpret_cast<LeafPage *>(curr_page);
        auto left_leaf = reinterpret_cast<LeafPage *>(left_sibling_page);
        //std::cout<<"leaf->GetSize():"<<leaf->GetSize()<<std::endl;
        // 在当前节点开头腾出空间
        for (int i = leaf->GetSize(); i > 0; i--) {
          leaf->SetKeyAt(i, leaf->KeyAt(i - 1));
          leaf->SetValueAt(i, leaf->ValueAt(i - 1));
        }
        
        // 借最后一个键值对
        int last_idx = left_leaf->GetSize() - 1;
        leaf->SetKeyAt(0, left_leaf->KeyAt(last_idx));
        leaf->SetValueAt(0, left_leaf->ValueAt(last_idx));
        
        // 更新大小
        leaf->SetSize(leaf->GetSize() + 1);
        left_leaf->SetSize(left_leaf->GetSize() - 1);
        
        // 更新父节点中的键
        parent->SetKeyAt(child_index, left_leaf->KeyAt(left_leaf->GetSize() - 1));
        
        return true;
      } else {
        // 当前节点是内部节点
        //std::cout<<"内部节点向左边借"<<std::endl;
        auto internal = reinterpret_cast<InternalPage *>(curr_page);
        auto left_internal = reinterpret_cast<InternalPage *>(left_sibling_page);
       // std::cout<<"internal->GetSize():"<<internal->GetSize()<<std::endl;
        // 在当前节点开头腾出空间
        for (int i = internal->GetSize()-1; i >= 0; i--) {
          //std::cout<<"i="<<i<<std::endl;
          //std::cout<<"internal->KeyAt(i-1):"<<internal->KeyAt(i-1).ToString()<<std::endl;
          internal->SetKeyAt(i+1, internal->KeyAt(i));
          internal->SetValueAt(i+1, internal->ValueAt(i));
        }
        
        // 借一个键和一个子节点
        int last_idx = left_internal->GetSize() - 1;
        internal->SetKeyAt(1, parent->KeyAt(child_index));
        internal->SetValueAt(0, left_internal->ValueAt(last_idx));
        
        // 更新父节点中的键
        internal->SetSize(internal->GetSize() + 1);
        parent->SetKeyAt(child_index, left_internal->KeyAt(last_idx));
        
        // 更新大小
        left_internal->SetSize(left_internal->GetSize() - 1);
        
        // 更新被移动的子节点的父指针
        WritePageGuard moved_child_guard = bpm_->WritePage(internal->ValueAt(0));
        auto moved_child = moved_child_guard.AsMut<BPlusTreePage>();
        moved_child->SetParentPageId(internal->GetPageId());
        
        //std::cout<<"借左兄弟成功"<<std::endl;
        return true;
      }
    }
  }
  
  // 检查是否可以从右兄弟借键
  if (child_index < parent->GetSize() - 1) {
    page_id_t right_sibling_id = parent->ValueAt(child_index + 1);
    WritePageGuard right_guard = bpm_->WritePage(right_sibling_id);
    BPlusTreePage *right_sibling_page = right_guard.AsMut<BPlusTreePage>();
    
    if (right_sibling_page->GetSize() > right_sibling_page->GetMinSize()) {
      // 可以从右兄弟借一个键
      if (curr_page->IsLeafPage()) {
        // 当前节点是叶节点
        auto leaf = reinterpret_cast<LeafPage *>(curr_page);
        auto right_leaf = reinterpret_cast<LeafPage *>(right_sibling_page);
        
        // 借右兄弟的第一个键值对
        leaf->SetKeyAt(leaf->GetSize(), right_leaf->KeyAt(0));
        leaf->SetValueAt(leaf->GetSize(), right_leaf->ValueAt(0));
        
        // 在右兄弟中移除借出的键值对
        for (int i = 0; i < right_leaf->GetSize() - 1; i++) {
          right_leaf->SetKeyAt(i, right_leaf->KeyAt(i + 1));
          right_leaf->SetValueAt(i, right_leaf->ValueAt(i + 1));
        }
        
        // 更新大小
        leaf->SetSize(leaf->GetSize() + 1);
        right_leaf->SetSize(right_leaf->GetSize() - 1);
        
        // 更新父节点中的键
        parent->SetKeyAt(child_index + 1, leaf->KeyAt(leaf->GetSize() - 1));
        
        return true;
      } else {
        // 当前节点是内部节点
        auto internal = reinterpret_cast<InternalPage *>(curr_page);
        auto right_internal = reinterpret_cast<InternalPage *>(right_sibling_page);
        //std::cout<<"internal开始向右兄弟借键"<<std::endl;
        // 借右兄弟的第一个子节点
        internal->SetKeyAt(internal->GetSize(), parent->KeyAt(child_index + 1));
        internal->SetValueAt(internal->GetSize(), right_internal->ValueAt(0));
        
        // 更新父节点中的键
        parent->SetKeyAt(child_index + 1, right_internal->KeyAt(1));
        
        // 在右兄弟中移除借出的键值对
        for (int i = 0; i < right_internal->GetSize() - 1; i++) {
          if (i > 0) {
            right_internal->SetKeyAt(i, right_internal->KeyAt(i + 1));
          }
          right_internal->SetValueAt(i, right_internal->ValueAt(i + 1));
        }
        
        // 更新大小
        internal->SetSize(internal->GetSize() + 1);
        right_internal->SetSize(right_internal->GetSize() - 1);
        
        // 更新被移动的子节点的父指针
        WritePageGuard moved_child_guard = bpm_->WritePage(internal->ValueAt(internal->GetSize() - 1));
        auto moved_child = moved_child_guard.AsMut<BPlusTreePage>();
        moved_child->SetParentPageId(internal->GetPageId());
        
        //std::cout<<"借右兄弟成功"<<std::endl;

        return true;
      }
    }
  }
  
  // 如果不能借，则需要合并节点
  // 优先与左兄弟合并
  if (child_index > 0) {
    page_id_t left_sibling_id = parent->ValueAt(child_index - 1);
    WritePageGuard left_guard = bpm_->WritePage(left_sibling_id);
    BPlusTreePage *left_sibling_page = left_guard.AsMut<BPlusTreePage>();
    
    // 合并当前节点到左兄弟
    if (curr_page->IsLeafPage()) {
      auto leaf = reinterpret_cast<LeafPage *>(curr_page);
      auto left_leaf = reinterpret_cast<LeafPage *>(left_sibling_page);
      
      //std::cout<<"curr_page"<<curr_page->GetPageId()<<std::endl;

      // 复制当前节点的键值对到左兄弟
      for (int i = 0; i < leaf->GetSize(); i++) {
        left_leaf->SetKeyAt(left_leaf->GetSize() + i, leaf->KeyAt(i));
        left_leaf->SetValueAt(left_leaf->GetSize() + i, leaf->ValueAt(i));
      }
      
      // 更新左兄弟的大小和next指针
      left_leaf->SetSize(left_leaf->GetSize() + leaf->GetSize());
      left_leaf->SetNextPageId(leaf->GetNextPageId());
      
      // 从父节点中删除当前节点的索引
      for (int i = child_index; i < parent->GetSize() - 1; i++) {
        parent->SetKeyAt(i, parent->KeyAt(i + 1));
        parent->SetValueAt(i, parent->ValueAt(i + 1));
      }
      parent->SetSize(parent->GetSize() - 1);
      
      // 释放当前节点
      bpm_->DeletePage(curr_page->GetPageId());
      //std::cout<<"叶节点合并左兄弟成功"<<std::endl;

    } 
    else {
      auto internal = reinterpret_cast<InternalPage *>(curr_page);
      auto left_internal = reinterpret_cast<InternalPage *>(left_sibling_page);

      //std::cout<<"curr_page : "<<curr_page->GetPageId()<<std::endl;  

      // 添加父节点中的键到左兄弟
      left_internal->SetKeyAt(left_internal->GetSize(), parent->KeyAt(child_index));
      
      // 复制当前节点的键值对到左兄弟
      for (int i = 0; i < internal->GetSize(); i++) {
        if (i > 0) {
          left_internal->SetKeyAt(left_internal->GetSize() , internal->KeyAt(i));
        }
        left_internal->SetValueAt(left_internal->GetSize(), internal->ValueAt(i));
        
        // 更新子节点的父指针
        WritePageGuard child_guard = bpm_->WritePage(internal->ValueAt(i));
        auto child = child_guard.AsMut<BPlusTreePage>();
        child->SetParentPageId(left_internal->GetPageId());
      
        left_internal->SetSize(left_internal->GetSize() + 1);
      }
      
      // 从父节点中删除当前节点的索引
      for (int i = child_index; i < parent->GetSize() - 1; i++) {
        parent->SetKeyAt(i, parent->KeyAt(i + 1));
        parent->SetValueAt(i, parent->ValueAt(i + 1));
      }
      parent->SetSize(parent->GetSize() - 1);
      
      // 释放当前节点
      bpm_->DeletePage(curr_page->GetPageId());
      //std::cout<<"parent_Page_Id"<<parent->GetPageId()<<std::endl;
      //std::cout<<"内部节点合并左兄弟成功"<<std::endl;
      
    }
    // 在与左节点结合之后检查父节点是否是根节点且只有一个子节点
    if (ctx->IsRootPage(parent_page->GetPageId()) && parent->GetSize() == 1) {
      //std::cout << "【合并后优化】父节点是根节点且只有一个子节点" << std::endl;
      
      // 获取根节点唯一的子节点ID（此时就是左兄弟节点）
      page_id_t left_page_id = left_sibling_page->GetPageId();
      //std::cout<<"left_page_id"<<left_page_id<<std::endl;
      
      // 设置左兄弟节点为新的根节点
      left_sibling_page->SetParentPageId(INVALID_PAGE_ID);
      
      // 更新头页面，将根节点指针指向左兄弟节点
      WritePageGuard header_guard = bpm_->WritePage(header_page_id_);
      auto header_page = header_guard.AsMut<BPlusTreeHeaderPage>();
      /*std::cout << "【合并后优化】更新根页面ID: " << header_page->root_page_id_ 
                << " -> " << left_page_id << std::endl;*/
      header_page->root_page_id_ = left_page_id;
      
      //std::cout<<"header_page_id_ : "<<header_page->root_page_id_<<std::endl;
      // 保存根节点ID以便后续删除
      page_id_t old_root_id = parent_page->GetPageId();
      
      // 调整上下文中的写集合
      // 先移除当前页面的写守卫(它已经被删除了)
      ctx->write_set_.pop_back();
      
      // 释放旧根节点
      bpm_->DeletePage(old_root_id);
      
      //std::cout << "【合并后优化】成功删除根节点，树高度减少" << std::endl;
    }
  } 
  else if (child_index < parent->GetSize() - 1) {
    // 与右兄弟合并
    page_id_t right_sibling_id = parent->ValueAt(child_index + 1);
    WritePageGuard right_guard = bpm_->WritePage(right_sibling_id);
    BPlusTreePage *right_sibling_page = right_guard.AsMut<BPlusTreePage>();
    
    // 合并右兄弟到当前节点
    if (curr_page->IsLeafPage()) {
      auto leaf = reinterpret_cast<LeafPage *>(curr_page);
      auto right_leaf = reinterpret_cast<LeafPage *>(right_sibling_page);
      
      // 复制右兄弟的键值对到当前节点
      for (int i = 0; i < right_leaf->GetSize(); i++) {
        leaf->SetKeyAt(leaf->GetSize() + i, right_leaf->KeyAt(i));
        leaf->SetValueAt(leaf->GetSize() + i, right_leaf->ValueAt(i));
      }
      
      // 更新当前节点的大小和next指针
      leaf->SetSize(leaf->GetSize() + right_leaf->GetSize());
      leaf->SetNextPageId(right_leaf->GetNextPageId());
      
      // 从父节点中删除右兄弟的索引
      for (int i = child_index + 1; i < parent->GetSize() - 1; i++) {
        parent->SetKeyAt(i, parent->KeyAt(i + 1));
        parent->SetValueAt(i, parent->ValueAt(i + 1));
      }
      parent->SetSize(parent->GetSize() - 1);
      
      //std::cout << "合并后的叶节点内容 (页面ID: " << leaf->GetPageId() << "):" << std::endl;
      for (int i = 0; i < leaf->GetSize(); i++) {
      /*std::cout << "  Key at " << i << ": " << leaf->KeyAt(i).ToString() 
            << ", RID: (" << leaf->ValueAt(i).GetPageId() 
            << "," << leaf->ValueAt(i).GetSlotNum() << ")" << std::endl;*/
          }
      // 释放右兄弟节点
      bpm_->DeletePage(right_sibling_page->GetPageId());
      //std::cout<<"叶节点合并右兄弟成功"<<std::endl;

    } 
    else {
      auto internal = reinterpret_cast<InternalPage *>(curr_page);
      auto right_internal = reinterpret_cast<InternalPage *>(right_sibling_page);
      
      // 添加父节点中的键到当前节点
      internal->SetKeyAt(internal->GetSize(), parent->KeyAt(child_index + 1));
      
      // 复制右兄弟的键值对到当前节点
      for (int i = 0; i < right_internal->GetSize(); i++) {
        if (i > 0) {
          internal->SetKeyAt(internal->GetSize(), right_internal->KeyAt(i));
        }
        internal->SetValueAt(internal->GetSize() , right_internal->ValueAt(i));
        
        // 更新子节点的父指针
        WritePageGuard child_guard = bpm_->WritePage(right_internal->ValueAt(i));
        auto child = child_guard.AsMut<BPlusTreePage>();
        child->SetParentPageId(internal->GetPageId());
  
        internal->SetSize(internal->GetSize() + 1);
      }
      
      // 从父节点中删除右兄弟的索引
      for (int i = child_index + 1; i < parent->GetSize() - 1; i++) {
        parent->SetKeyAt(i, parent->KeyAt(i + 1));
        parent->SetValueAt(i, parent->ValueAt(i + 1));
      }
      parent->SetSize(parent->GetSize() - 1);
      
      // 释放右兄弟节点
      bpm_->DeletePage(right_sibling_page->GetPageId());
      //std::cout<<"内部结点合并右兄弟成功"<<std::endl;

    }
     // 在与右节点结合之后检查父节点是否是根节点且只有一个子节点
    if (ctx->IsRootPage(parent_page->GetPageId()) && parent->GetSize() == 1) {
      //std::cout << "【合并后优化】父节点是根节点且只有一个子节点" << std::endl;
  
      // 获取根节点唯一的子节点ID（此时就是当前节点，因为右兄弟被合并到当前节点）
      page_id_t curr_page_id = curr_page->GetPageId();
  
      // 设置当前节点为新的根节点
      curr_page->SetParentPageId(INVALID_PAGE_ID);
  
     // 更新头页面，将根节点指针指向当前节点
     WritePageGuard header_guard = bpm_->WritePage(header_page_id_);
     auto header_page = header_guard.AsMut<BPlusTreeHeaderPage>();
     /*std::cout << "【合并后优化】更新根页面ID: " << header_page->root_page_id_ 
            << " -> " << curr_page_id << std::endl;*/
     header_page->root_page_id_ = curr_page_id;
  
     // 保存根节点ID以便后续删除
     page_id_t old_root_id = parent_page->GetPageId();
  
      // 调整上下文中的写集合
      // 先移除当前页面的写守卫(它已经被删除了)
     ctx->write_set_.pop_back();
  
      // 释放旧根节点
      bpm_->DeletePage(old_root_id);
  
      //std::cout << "【合并后优化】成功删除根节点，树高度减少" << std::endl;
    }
  }
  //std::cout<<"parent->GetSize() : "<<parent->GetSize()<<std::endl;
  //std::cout << "【调整】调整完成" << std::endl;
  // 检查父节点是否需要调整
  if (parent->GetSize() < parent->GetMinSize() && !ctx->IsRootPage(parent->GetPageId())) {
    // 弹出当前节点，继续循环处理父节点
    ctx->write_set_.pop_back();
    // 不再递归调用，而是通过循环继续处理
    continue;
  }
  
  // 不需要继续调整
  break;
  }
  return true;
}
/*****************************************************************************
 * INDEX ITERATOR
 *****************************************************************************/
/**
 * @brief Input parameter is void, find the leftmost leaf page first, then construct
 * index iterator
 *
 * You may want to implement this while implementing Task #3.
 *
 * @return : index iterator
 */
 INDEX_TEMPLATE_ARGUMENTS
 auto BPLUSTREE_TYPE::Begin() -> INDEXITERATOR_TYPE { 
   // 如果树为空，返回End()
   if (IsEmpty()) {
     return End();
   }
   
   // 获取根页面ID
   ReadPageGuard header_guard = bpm_->ReadPage(header_page_id_);
   auto header_page = header_guard.As<BPlusTreeHeaderPage>();
   page_id_t root_page_id = header_page->root_page_id_;
   
   // 从根节点开始查找最左叶节点
   page_id_t page_id = root_page_id;
   while (true) {
     ReadPageGuard page_guard = bpm_->ReadPage(page_id);
     auto page = page_guard.As<BPlusTreePage>();
     
     if (page->IsLeafPage()) {
       // 找到最左叶节点，不需要查找键，直接使用索引0
       // 保存页面ID
       page_id_t leaf_page_id = page_id;
       // 显式释放页面
       page_guard.Drop();
       // 创建迭代器，从索引0开始
       return INDEXITERATOR_TYPE(leaf_page_id, 0, bpm_);
     }
     
     // 当前页是内部节点，继续向左查找
     auto internal_page = reinterpret_cast<const InternalPage *>(page);
     page_id_t next_page_id = internal_page->ValueAt(0);
   
     // 在获取新页面之前释放当前页面
     page_guard.Drop();
   
     page_id = next_page_id;
   }
 }
/**
 * @brief Input parameter is low key, find the leaf page that contains the input key
 * first, then construct index iterator
 * @return : index iterator
 */
 INDEX_TEMPLATE_ARGUMENTS
 auto BPLUSTREE_TYPE::Begin(const KeyType &key) -> INDEXITERATOR_TYPE {
    // 如果树为空，返回End()
    if (IsEmpty()) {
      return End();
    }
 
    // 获取根页面ID
    ReadPageGuard header_guard = bpm_->ReadPage(header_page_id_);
    auto header_page = header_guard.As<BPlusTreeHeaderPage>();
    page_id_t root_page_id = header_page->root_page_id_;
 
    // 从根节点开始查找包含key的叶节点
    page_id_t page_id = root_page_id;
    while (true) {
      ReadPageGuard page_guard = bpm_->ReadPage(page_id);
      auto page = page_guard.As<BPlusTreePage>();
 
      if (page->IsLeafPage()) {
        // 找到叶节点，在叶节点中查找键
        auto leaf_page = reinterpret_cast<const LeafPage *>(page);
        // 使用KeyIndex查找键的位置
        int index = leaf_page->KeyIndex(key, comparator_);
        // 保存需要的值，然后释放页面
        page_id_t leaf_page_id = page_id;
        int leaf_index = index;
        // 显式释放页面
        page_guard.Drop();
        // 创建迭代器，从找到的索引位置开始
        return INDEXITERATOR_TYPE(leaf_page_id, leaf_index, bpm_);
      }
      // 当前页是内部节点，继续向下查找
      auto internal_page = reinterpret_cast<const InternalPage *>(page);
      // 在内部节点中查找键应该去的子节点
      int child_index = 0;
      int size = internal_page->GetSize();
      // 寻找第一个大于等于key的键的索引
      for (int i = 1; i < size; i++) {
        if (comparator_(key, internal_page->KeyAt(i)) <= 0) {
          break;
        }
        child_index = i;
      }
      // 获取子节点页面ID
      page_id_t next_page_id = internal_page->ValueAt(child_index);
      // 在获取新页面前释放当前页面
      page_guard.Drop();
      page_id = next_page_id;
    }
 }

/**
 * @brief Input parameter is void, construct an index iterator representing the end
 * of the key/value pair in the leaf node
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::End() -> INDEXITERATOR_TYPE {
  // 创建一个表示末尾的迭代器
  return INDEXITERATOR_TYPE(INVALID_PAGE_ID, 0, bpm_);
 }

/**
 * @return Page id of the root of this tree
 *
 * You may want to implement this while implementing Task #3.
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetRootPageId() -> page_id_t { 
  // 从缓冲池中读取 header page
  ReadPageGuard guard = bpm_->ReadPage(header_page_id_);
  // 获取 header page 的指针
  auto header_page = guard.As<BPlusTreeHeaderPage>();
  // 返回 header page 中存储的 root page id
  return header_page->root_page_id_;
}

template class BPlusTree<GenericKey<4>, RID, GenericComparator<4>>;

template class BPlusTree<GenericKey<8>, RID, GenericComparator<8>>;

template class BPlusTree<GenericKey<16>, RID, GenericComparator<16>>;

template class BPlusTree<GenericKey<32>, RID, GenericComparator<32>>;

template class BPlusTree<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub