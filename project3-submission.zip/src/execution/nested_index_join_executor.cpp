//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nested_index_join_executor.cpp
//
// Identification: src/execution/nested_index_join_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/nested_index_join_executor.h"
#include "type/value_factory.h"

namespace bustub {

/**
 * Creates a new nested index join executor.
 * @param exec_ctx the context that the nested index join should be performed in
 * @param plan the nested index join plan to be executed
 * @param child_executor the outer table
 */
NestIndexJoinExecutor::NestIndexJoinExecutor(ExecutorContext *exec_ctx, const NestedIndexJoinPlanNode *plan,
                                             std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      child_executor_(std::move(child_executor)) {
  if (!(plan->GetJoinType() == JoinType::LEFT || plan->GetJoinType() == JoinType::INNER)) {
    // Note for 2023 Spring: You ONLY need to implement left join and inner join.
    throw bustub::NotImplementedException(fmt::format("join type {} not supported", plan->GetJoinType()));
  }
}

void NestIndexJoinExecutor::Init() { 
  // 初始化成员变量
  child_executor_->Init();
  inner_tuple_idx_ = 0;
  inner_tuples_.clear();
  is_end_ = false;
  left_has_match_ = false;
  
  // 获取索引信息
  index_info_ = exec_ctx_->GetCatalog()->GetIndex(plan_->index_oid_);
  table_info_ = exec_ctx_->GetCatalog()->GetTable(plan_->inner_table_oid_);
  
  outer_tuple_ = Tuple{};  // 初始化为空元组
}

auto NestIndexJoinExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  const auto &outer_schema = child_executor_->GetOutputSchema();
  const auto &inner_schema = plan_->InnerTableSchema();

  while (true) {
    // 1. 处理当前外部元组的匹配项
    if (outer_tuple_.GetData() != nullptr && inner_tuple_idx_ < inner_tuples_.size()) {
      auto &[inner_rid, inner_tuple] = inner_tuples_[inner_tuple_idx_++];

      std::vector<Value> values;
      const auto &output_schema = plan_->OutputSchema();
      
      // 添加外部元组的所有列
      for (uint32_t i = 0; i < outer_schema.GetColumnCount(); i++) {
        values.push_back(outer_tuple_.GetValue(&outer_schema, i));
      }
      
      // 添加内部元组的所有列
      for (uint32_t i = 0; i < inner_schema.GetColumnCount(); i++) {
        values.push_back(inner_tuple.GetValue(&inner_schema, i));
      }

      *tuple = Tuple(values, &output_schema);
      *rid = inner_rid;
      return true;
    }

    // 2. 处理LEFT JOIN无匹配情况
    if (outer_tuple_.GetData() != nullptr && plan_->GetJoinType() == JoinType::LEFT && !left_has_match_) {
      std::vector<Value> values;
      const auto &output_schema = plan_->OutputSchema();
      
      // 添加外部元组的所有列
      for (uint32_t i = 0; i < outer_schema.GetColumnCount(); i++) {
        values.push_back(outer_tuple_.GetValue(&outer_schema, i));
      }
      
      // 为内部表的列添加NULL值
      for (uint32_t i = 0; i < inner_schema.GetColumnCount(); i++) {
        values.push_back(ValueFactory::GetNullValueByType(inner_schema.GetColumn(i).GetType()));
      }

      *tuple = Tuple(values, &output_schema);
      left_has_match_ = true;
      *rid = outer_rid_;
      return true;
    }

    // 3. 获取下一个外部元组
    if (!child_executor_->Next(&outer_tuple_, &outer_rid_)) {
      is_end_ = true;
      return false;
    }

    // 4. 为新的外部元组查找匹配
    inner_tuples_.clear();
    inner_tuple_idx_ = 0;
    left_has_match_ = false;

    Tuple probe_key = ConstructProbeKey(&outer_tuple_);
    
    std::vector<RID> result_rids;
    index_info_->index_->ScanKey(probe_key, &result_rids, exec_ctx_->GetTransaction());

    for (auto &found_rid : result_rids) {
      auto [tuple_meta, inner_tuple_candidate] = table_info_->table_->GetTuple(found_rid);
      if (!tuple_meta.is_deleted_) {
        inner_tuples_.push_back(std::make_pair(found_rid, inner_tuple_candidate));
      }
    }

    if (!inner_tuples_.empty()) {
      left_has_match_ = true;
    }
  }
}

// 正确构造索引探测键
Tuple NestIndexJoinExecutor::ConstructProbeKey(const Tuple *outer_tuple) {
  const auto &key_schema = index_info_->index_->GetKeySchema();
  std::vector<Value> key_values;
  
  // **使用计划节点提供的 KeyPredicate 来动态获取正确的列值**
  const auto &key_predicate = plan_->KeyPredicate();
  
  if (key_predicate != nullptr) {
    // 使用键谓词来计算外部元组的键值
    // KeyPredicate 会自动处理列索引的解析
    Value probe_value = key_predicate->Evaluate(outer_tuple, child_executor_->GetOutputSchema());
    
    // 确保类型与索引键类型匹配
    TypeId index_key_type = key_schema->GetColumn(0).GetType();
    if (probe_value.GetTypeId() != index_key_type) {
      probe_value = probe_value.CastAs(index_key_type);
    }
    
    key_values.push_back(probe_value);
  } else {
    throw Exception("KeyPredicate is null in NestedIndexJoinPlanNode");
  }
  
  return Tuple(key_values, key_schema);
}


}  // namespace bustub
