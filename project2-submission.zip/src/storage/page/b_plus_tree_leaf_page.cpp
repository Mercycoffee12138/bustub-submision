//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree_leaf_page.cpp
//
// Identification: src/storage/page/b_plus_tree_leaf_page.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <sstream>

#include "common/exception.h"
#include "common/rid.h"
#include "storage/page/b_plus_tree_leaf_page.h"

namespace bustub {

/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/

/**
 * @brief Init method after creating a new leaf page
 *
 * After creating a new leaf page from buffer pool, must call initialize method to set default values,
 * including set page type, set current size to zero, set page id/parent id, set
 * next page id and set max size.
 *
 * @param max_size Max size of the leaf node
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::Init(int max_size) { 
  // 设置页面类型为叶节点
  SetPageType(IndexPageType::LEAF_PAGE);
  // 初始时，叶节点大小为0，没有键值对
  SetSize(0);
  // 设置最大页面大小
  SetMaxSize(max_size);
  // 初始化next_page_id为INVALID_PAGE_ID，表示没有下一个页面
  next_page_id_ = INVALID_PAGE_ID;
 }

/**
 * Helper methods to set/get next page id
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::GetNextPageId() const -> page_id_t { 
  return next_page_id_;
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::SetNextPageId(page_id_t next_page_id) {
  next_page_id_ = next_page_id;
}

/*
 * Helper method to find and return the key associated with input "index" (a.k.a
 * array offset)
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::KeyAt(int index) const -> KeyType { 
  // 确保索引在有效范围内
  assert(index >= 0 );
  return key_array_[index];
 }

// 添加新方法实现

/*
 * Helper method to set the key at specified index
 */
 INDEX_TEMPLATE_ARGUMENTS
 void B_PLUS_TREE_LEAF_PAGE_TYPE::SetKeyAt(int index, const KeyType &key) {
  assert(index >= 0 );  // 注意使用<=而不是<
  key_array_[index] = key;
}
 
 /*
  * Helper method to get the value at specified index
  */
 INDEX_TEMPLATE_ARGUMENTS
 auto B_PLUS_TREE_LEAF_PAGE_TYPE::ValueAt(int index) const -> ValueType {
   assert(index >= 0 );
   return rid_array_[index];
 }
 
 /*
  * Helper method to set the value at specified index
  */
 INDEX_TEMPLATE_ARGUMENTS
 void B_PLUS_TREE_LEAF_PAGE_TYPE::SetValueAt(int index, const ValueType &value) {
   assert(index >= 0);
   rid_array_[index] = value;
 }
 
 /*
  * Helper method to find the first index i so that key[i] >= target_key or
  * i == GetSize() if all keys are smaller than target_key
  */
 INDEX_TEMPLATE_ARGUMENTS
 auto B_PLUS_TREE_LEAF_PAGE_TYPE::KeyIndex(const KeyType &key, const KeyComparator &comparator) const -> int {
   int left = 0;
   int right = GetSize() - 1;
   
   // 二分查找
   while (left <= right) {
     int mid = left + (right - left) / 2;
     if (comparator(key_array_[mid], key) < 0) {
       // 当前键小于目标键，查找右侧
       left = mid + 1;
     } else if (comparator(key_array_[mid], key) > 0) {
       // 当前键大于目标键，查找左侧
       right = mid - 1;
     } else {
       // 找到匹配的键
       return mid;
     }
   }
   // 返回应该插入的位置
   return left;
 }

 INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::Insert(const KeyType &key, const ValueType &value, const KeyComparator &comparator) {
  // 找到适当的插入位置
  int insert_index = KeyIndex(key, comparator);
  
  // 如果键已存在，则替换值（假设不允许重复键）
  if (insert_index < GetSize() && comparator(KeyAt(insert_index), key) == 0) {
    SetValueAt(insert_index, value);
    return;
  }
  
  // 先保存当前大小
  int current_size = GetSize();
  
  // 先增加页面大小 - 这是关键改变
  SetSize(current_size + 1);
  
  // 将插入位置后的所有键值对向后移动一位
  for (int i = current_size; i > insert_index; i--) {
    key_array_[i] = key_array_[i - 1];  // 直接操作数组，避免断言问题
    rid_array_[i] = rid_array_[i - 1];  // 直接操作数组，避免断言问题
  }
  
  // 在找到的位置插入新键值对
  key_array_[insert_index] = key;  // 直接操作数组
  rid_array_[insert_index] = value;  // 直接操作数组
}

template class BPlusTreeLeafPage<GenericKey<4>, RID, GenericComparator<4>>;
template class BPlusTreeLeafPage<GenericKey<8>, RID, GenericComparator<8>>;
template class BPlusTreeLeafPage<GenericKey<16>, RID, GenericComparator<16>>;
template class BPlusTreeLeafPage<GenericKey<32>, RID, GenericComparator<32>>;
template class BPlusTreeLeafPage<GenericKey<64>, RID, GenericComparator<64>>;
}  // namespace bustub