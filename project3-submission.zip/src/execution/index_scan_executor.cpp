//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// index_scan_executor.cpp
//
// Identification: src/execution/index_scan_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/index_scan_executor.h"
#include "common/macros.h"
#include "catalog/catalog.h"
#include "storage/index/extendible_hash_table_index.h"
#include "storage/table/tuple.h"
#include "type/value.h"
#include "execution/expressions/constant_value_expression.h"

namespace bustub {

/**
 * Creates a new index scan executor.
 * @param exec_ctx the executor context
 * @param plan the index scan plan to be executed
 */
IndexScanExecutor::IndexScanExecutor(ExecutorContext *exec_ctx, const IndexScanPlanNode *plan)
    : AbstractExecutor(exec_ctx) ,plan_(plan){}

void IndexScanExecutor::Init() { 
  index_scan_finish_ = false;
  // 获取索引和表信息
  IndexInfo *index_info = GetExecutorContext()->GetCatalog()->GetIndex(plan_->index_oid_).get();
  TableInfo *table_info = GetExecutorContext()->GetCatalog()->GetTable(plan_->table_oid_).get();
  // 获取表堆和B+树索引
  table_heap_ = table_info->table_.get();
  tree_ = dynamic_cast<BPlusTreeIndexForTwoIntegerColumn *>(index_info->index_.get());
  // 清空之前的RID列表
  rids_.clear();
  // 检查是点查找还是顺序查找
  if (!plan_->pred_keys_.empty()) {
    is_point_lookup_ = true;  // 这一行是关键修改
    // 遍历所有谓词键 (处理OR条件的多个键值)
    for (const auto &expr_ptr : plan_->pred_keys_) {
      const auto *const_expr = dynamic_cast<const ConstantValueExpression *>(expr_ptr.get());
      if (const_expr == nullptr) {
        throw std::runtime_error("索引扫描谓词不是常量表达式");
      }
      // 获取查询值
      Value key_value = const_expr->val_;
      // 创建键值元组
      std::vector<Value> values{key_value};
      Tuple key_tuple(values, &index_info->key_schema_);
      // 使用ScanKey获取匹配的RIDs并添加到rids_列表
      tree_->ScanKey(key_tuple, &rids_, GetExecutorContext()->GetTransaction());
    }
    // 初始化RID迭代器
    rid_iter_ = rids_.begin();
  } else {
    // 顺序查找模式 - 按索引列排序
    is_point_lookup_ = false;
    // 初始化B+树迭代器，从树的起始位置开始
    new (&tree_iterator_) IndexIterator<GenericKey<8>, RID, GenericComparator<8>>(tree_->GetBeginIterator());
  }
}

auto IndexScanExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  // 如果扫描已完成，直接返回false
  if (index_scan_finish_) {
    return false;
  }
  // 根据不同的扫描模式进行处理
  if (is_point_lookup_) {
    // 点查找模式 - 使用RIDs迭代器
    while (rid_iter_ != rids_.end()) {
      // 获取当前RID并前进迭代器
      RID current_rid = *rid_iter_;
      ++rid_iter_;
      // 检查元组是否已删除
      auto tuple_meta = table_heap_->GetTupleMeta(current_rid);
      // 打印调试信息
      std::cout << "检查RID: " << current_rid.ToString() 
                << ", 是否删除: " << (tuple_meta.is_deleted_ ? "是" : "否") << std::endl;
      if (!tuple_meta.is_deleted_) {
        // 获取未删除的元组
        *tuple = table_heap_->GetTuple(current_rid).second;
        *rid = current_rid;
        return true;  // 找到有效元组
      }
    }
    // 所有RID都已处理完，标记扫描结束
    index_scan_finish_ = true;
    return false;
  } else {
    // 有序扫描模式 - 使用B+树迭代器
    while (!tree_iterator_.IsEnd()) {
      // 获取当前记录的RID
      RID current_rid = (*tree_iterator_).second;
      // 前进迭代器到下一个位置
      ++tree_iterator_;
      // 从表堆中获取元组
      auto [tuple_meta, fetched_tuple] = table_heap_->GetTuple(current_rid);
      // 检查元组是否已删除
      if (tuple_meta.is_deleted_) {
        // 如果元组已删除，继续检查下一个
        continue;
      }
      // 检查谓词条件（如果存在）
      if (plan_->filter_predicate_ != nullptr) {
        if (!plan_->filter_predicate_->Evaluate(&fetched_tuple, GetOutputSchema()).GetAs<bool>()) {
          // 不满足过滤条件，继续检查下一个
          continue;
        }
      }
      // 如果元组有效并满足条件，填充输出结果
      *tuple = fetched_tuple;
      *rid = current_rid;
      return true;
    }
    // 迭代器到达末尾，标记扫描结束
    index_scan_finish_ = true;
    return false;
  }
}

}  // namespace bustub
