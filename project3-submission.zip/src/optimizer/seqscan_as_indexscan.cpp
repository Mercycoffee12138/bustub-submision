//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seqscan_as_indexscan.cpp
//
// Identification: src/optimizer/seqscan_as_indexscan.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <cstddef>
#include <cstdint>
#include <memory>
#include <utility>
#include <vector>
#include "execution/expressions/column_value_expression.h"
#include "execution/expressions/comparison_expression.h"
#include "execution/expressions/constant_value_expression.h"
#include "execution/expressions/logic_expression.h"
#include "execution/plans/abstract_plan.h"
#include "execution/plans/index_scan_plan.h"
#include "execution/plans/seq_scan_plan.h"
#include "optimizer/optimizer.h"
#include "type/type.h"

namespace bustub {

/**
 * @brief optimize seq scan as index scan if there's an index on a table
 * @note Fall 2023 only: using hash index and only support point lookup
 */
auto Optimizer::OptimizeSeqScanAsIndexScan(const bustub::AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef {
  // TODO(student): implement seq scan with predicate -> index scan optimizer rule
  // The Filter Predicate Pushdown has been enabled for you in optimizer.cpp when forcing starter rule
  // 递归优化子计划
  std::vector<AbstractPlanNodeRef> children;
  for (const auto &child : plan->GetChildren()) {
    children.emplace_back(OptimizeSeqScanAsIndexScan(child));
  }
  auto optimized_plan = plan->CloneWithChildren(std::move(children));
  // 检查是否是 SeqScan
  if (optimized_plan->GetType() == PlanType::SeqScan) {
    const auto &seq_scan = dynamic_cast<const SeqScanPlanNode &>(*optimized_plan);
    // 没有过滤谓词，无需优化
    if (seq_scan.filter_predicate_ == nullptr) {
      return optimized_plan;
    }
    // 处理OR逻辑表达式 (如 v1 = 4 OR v1 = 7)
    auto logic_expr = dynamic_cast<const LogicExpression *>(seq_scan.filter_predicate_.get());
    if (logic_expr != nullptr && logic_expr->logic_type_ == LogicType::Or) {
      // 初始化用于收集等值条件的变量
      std::vector<AbstractExpressionRef> pred_keys;
      uint32_t col_idx = static_cast<uint32_t>(-1); // 初始化为无效值
      bool all_equal_on_same_col = true;
      
      // 调用辅助函数收集OR条件中的等值谓词
      if (!CollectEqualPredicatesFromOR(logic_expr, pred_keys, col_idx)) {
        all_equal_on_same_col = false;
      }
      
      // 如果所有条件都是相同列的等值条件且成功收集了谓词键
      if (all_equal_on_same_col && !pred_keys.empty() && col_idx != static_cast<uint32_t>(-1)) {
        // 获取表信息
        const auto &table_name = seq_scan.table_name_;
        auto table_info = catalog_.GetTable(seq_scan.table_oid_);
        
        // 获取表的所有索引
        auto table_indexes = catalog_.GetTableIndexes(table_name);
        
        // 检查是否有索引匹配该列
        for (const auto &index_info : table_indexes) {
          const auto &key_attrs = index_info->index_->GetKeyAttrs();
          if (key_attrs.size() == 1 && key_attrs[0] == col_idx) {
            // 找到了匹配的索引，创建IndexScan节点
            return std::make_shared<IndexScanPlanNode>(
                seq_scan.output_schema_,
                seq_scan.table_oid_,
                index_info->index_oid_,
                seq_scan.filter_predicate_,
                pred_keys);
          }
        }
      }
    }
    // 处理单个等值比较 (如 v1 = 2 或 2 = v1)
    auto comp_expr = dynamic_cast<const ComparisonExpression *>(seq_scan.filter_predicate_.get());
    if (comp_expr != nullptr && comp_expr->comp_type_ == ComparisonType::Equal) {
      // 提取列表达式和常量表达式
      const ColumnValueExpression *col_expr = nullptr;
      const ConstantValueExpression *const_expr = nullptr;
      
      // 检查左侧是列表达式，右侧是常量
      if (auto left_col = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[0].get())) {
        col_expr = left_col;
        const_expr = dynamic_cast<const ConstantValueExpression *>(comp_expr->children_[1].get());
      }
      // 检查右侧是列表达式，左侧是常量 (WHERE 2 = v1)
      else if (auto right_col = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[1].get())) {
        col_expr = right_col;
        const_expr = dynamic_cast<const ConstantValueExpression *>(comp_expr->children_[0].get());
      }
      
      // 确认找到了列和常量
      if (col_expr != nullptr && const_expr != nullptr) {
        // 获取表信息
        const auto &table_name = seq_scan.table_name_;
        auto table_info = catalog_.GetTable(seq_scan.table_oid_);
        
        // 获取表的所有索引
        auto table_indexes = catalog_.GetTableIndexes(table_name);
        
        // 列索引
        uint32_t col_idx = col_expr->GetColIdx();
        
        // 检查列是否有索引
        for (const auto &index_info : table_indexes) {
          // 检查索引键列是否匹配
          const auto &key_attrs = index_info->index_->GetKeyAttrs();
          if (key_attrs.size() == 1 && key_attrs[0] == col_idx) {
            // 创建常量表达式的副本
            auto pred_key = std::make_shared<ConstantValueExpression>(const_expr->val_);
            
            // 创建谓词键向量并添加表达式
            std::vector<AbstractExpressionRef> pred_keys;
            pred_keys.push_back(pred_key);
            
            // 创建并返回 IndexScan 计划节点
            return std::make_shared<IndexScanPlanNode>(
                seq_scan.output_schema_,
                seq_scan.table_oid_,
                index_info->index_oid_,
                seq_scan.filter_predicate_,
                pred_keys);
          }
        }
      }
    }
  }
  // 没有找到可用索引或不是等值条件，返回原计划
  return optimized_plan;
}

bool Optimizer::CollectEqualPredicatesFromOR(const LogicExpression *expr, 
                                             std::vector<AbstractExpressionRef> &pred_keys,
                                             uint32_t &col_idx) {
  // 如果是逻辑表达式
  if (expr->logic_type_ == LogicType::Or) {
    // 处理左子表达式
    const auto &left_child = expr->GetChildAt(0);
    if (auto left_logic = dynamic_cast<const LogicExpression *>(left_child.get())) {
      // 左子节点是逻辑表达式，递归处理
      if (!CollectEqualPredicatesFromOR(left_logic, pred_keys, col_idx)) {
        return false;
      }
    } else {
      // 左子节点不是逻辑表达式，作为叶子节点处理
      auto left_comp = dynamic_cast<const ComparisonExpression *>(left_child.get());
      if (!ProcessComparisonNode(left_comp, pred_keys, col_idx)) {
        return false;
      }
    }
    // 处理右子表达式
    const auto &right_child = expr->GetChildAt(1);
    if (auto right_logic = dynamic_cast<const LogicExpression *>(right_child.get())) {
      // 右子节点是逻辑表达式，递归处理
      if (!CollectEqualPredicatesFromOR(right_logic, pred_keys, col_idx)) {
        return false;
      }
    } else {
      // 右子节点不是逻辑表达式，作为叶子节点处理
      auto right_comp = dynamic_cast<const ComparisonExpression *>(right_child.get());
      if (!ProcessComparisonNode(right_comp, pred_keys, col_idx)) {
        return false;
      }
    }
    return true;
  }
  // 表达式本身不是OR，尝试作为比较表达式处理
  auto comp_expr = dynamic_cast<const ComparisonExpression *>(expr);
  return ProcessComparisonNode(comp_expr, pred_keys, col_idx);
}

// 添加一个辅助函数处理比较节点
bool Optimizer::ProcessComparisonNode(const ComparisonExpression *comp_expr,
                                       std::vector<AbstractExpressionRef> &pred_keys,
                                       uint32_t &col_idx) {
  if (comp_expr == nullptr || comp_expr->comp_type_ != ComparisonType::Equal) {
    return false;
  }
  // 提取列表达式和常量表达式
  const ColumnValueExpression *col_expr = nullptr;
  const ConstantValueExpression *const_expr = nullptr;
  // 检查左侧是列表达式，右侧是常量
  if (auto left_col = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[0].get())) {
    col_expr = left_col;
    const_expr = dynamic_cast<const ConstantValueExpression *>(comp_expr->children_[1].get());
  }
  // 检查右侧是列表达式，左侧是常量
  else if (auto right_col = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[1].get())) {
    col_expr = right_col;
    const_expr = dynamic_cast<const ConstantValueExpression *>(comp_expr->children_[0].get());
  }
  // 确认找到了列和常量
  if (col_expr != nullptr && const_expr != nullptr) {
    // 检查是否是同一列的条件
    uint32_t current_col_idx = col_expr->GetColIdx();
    if (col_idx == static_cast<uint32_t>(-1)) {
      // 首次设置列索引
      col_idx = current_col_idx;
    } else if (col_idx != current_col_idx) {
      // 发现不同列的条件，无法使用索引扫描
      return false;
    }
    // 添加谓词键
    pred_keys.push_back(std::make_shared<ConstantValueExpression>(const_expr->val_));
    return true;
  }
  return false;
}
}  // namespace bustub
