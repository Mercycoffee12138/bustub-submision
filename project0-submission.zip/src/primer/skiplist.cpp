//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// skiplist.cpp
//
// Identification: src/primer/skiplist.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "primer/skiplist.h"
#include <cassert>
#include <cstddef>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include "common/macros.h"
#include "fmt/core.h"
#include<mutex>

namespace bustub {

/** @brief Checks whether the container is empty. */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Empty() -> bool {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  return header_->links_[0] == nullptr;
}

/** @brief Returns the number of elements in the skip list. */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Size() -> size_t {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  size_t size = 0;
  auto node = header_->Next(0);
  while (node != nullptr) {
    size++;
    node = node->Next(0);
  }
  return size;
}

/**
 * @brief Iteratively deallocate all the nodes.
 *
 * We do this to avoid stack overflow when the skip list is large.
 *
 * If we let the compiler handle the deallocation, it will recursively call the destructor of each node,
 * which could block up the the stack.
 */
SKIPLIST_TEMPLATE_ARGUMENTS void SkipList<K, Compare, MaxHeight, Seed>::Drop() {
  for (size_t i = 0; i < MaxHeight; i++) {
    auto curr = std::move(header_->links_[i]);
    while (curr != nullptr) {
      // std::move sets `curr` to the old value of `curr->links_[i]`,
      // and then resets `curr->links_[i]` to `nullptr`.
      curr = std::move(curr->links_[i]);
    }
  }
}

/**
 * @brief Removes all elements from the skip list.
 *
 * Note: You might want to use the provided `Drop` helper function.
 */
SKIPLIST_TEMPLATE_ARGUMENTS void SkipList<K, Compare, MaxHeight, Seed>::Clear() {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  Drop();
  for (size_t i = 0; i < MaxHeight; i++) {
    header_->links_[i] = nullptr;
  }
}

/**
 * @brief Inserts a key into the skip list.
 *
 * Note: `Insert` will not insert the key if it already exists in the skip list.
 *
 * @param key key to insert.
 * @return true if the insertion is successful, false if the key already exists.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Insert(const K &key) -> bool {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  std::unique_lock<std::shared_mutex> lock(rwlock_);  // 使用写锁

  std::vector<std::shared_ptr<SkipNode>> update(MaxHeight);
  auto curr = header_;
  
  // Find the position to insert the new node
  for (int i = MaxHeight - 1; i >= 0; i--) {
    while (curr->Next(i) != nullptr && compare_(curr->Next(i)->Key(), key)) {
      curr = curr->Next(i);
    }
    update[i] = curr;
  }
  
  curr = curr->Next(0);
  
  // If the key already exists, return false
  if (curr != nullptr && !compare_(key, curr->Key()) && !compare_(curr->Key(), key)) {
    return false;
  }
  
  // Generate a random height for the new node
  size_t node_height = RandomHeight();
  auto new_node = std::make_shared<SkipNode>(node_height, key);
  
  // Insert the new node
  for (size_t i = 0; i < node_height; i++) {
    new_node->SetNext(i, update[i]->Next(i));
    update[i]->SetNext(i, new_node);
  }
  
  return true;
}

/**
 * @brief Erases the key from the skip list.
 *
 * @param key key to erase.
 * @return bool true if the element got erased, false otherwise.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Erase(const K &key) -> bool {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  std::unique_lock<std::shared_mutex> lock(rwlock_);  // 使用写锁

  std::vector<std::shared_ptr<SkipNode>> update(MaxHeight);
  auto curr = header_;
  
  // Find the position of the node to be erased
  for (int i = MaxHeight - 1; i >= 0; i--) {
    while (curr->Next(i) != nullptr && compare_(curr->Next(i)->Key(), key)) {
      curr = curr->Next(i);
    }
    update[i] = curr;
  }
  
  curr = curr->Next(0);
  
  // If the key does not exist, return false
  if (curr == nullptr || compare_(key, curr->Key()) || compare_(curr->Key(), key)) {
    return false;
  }
  
  // Remove the node
  for (size_t i = 0; i < MaxHeight; i++) {
    if (update[i]->Next(i) != curr) {
      break;
    }
    update[i]->SetNext(i, curr->Next(i));
  }
  
  return true;
}

/**
 * @brief Checks whether a key exists in the skip list.
 *
 * @param key key to look up.
 * @return bool true if the element exists, false otherwise.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Contains(const K &key) -> bool {
  // Following the standard library: Key `a` and `b` are considered equivalent if neither compares less
  // than the other: `!compare_(a, b) && !compare_(b, a)`.
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  std::shared_lock<std::shared_mutex> lock(rwlock_);  // 使用读锁

  auto curr = header_;
  
  // Traverse the skip list from top level to bottom level
  for (int i = MaxHeight - 1; i >= 0; i--) {
    while (curr->Next(i) != nullptr && compare_(curr->Next(i)->Key(), key)) {
      curr = curr->Next(i);
    }
  }
  
  curr = curr->Next(0);
  
  // Check if the current node's key is equal to the given key
  if (curr != nullptr && !compare_(key, curr->Key()) && !compare_(curr->Key(), key)) {
    return true;
  }
  
  return false;
}

/**
 * @brief Prints the skip list for debugging purposes.
 *
 * Note: You may modify the functions in any way and the output is not tested.
 */
SKIPLIST_TEMPLATE_ARGUMENTS void SkipList<K, Compare, MaxHeight, Seed>::Print() {
  auto node = header_->Next(LOWEST_LEVEL);
  while (node != nullptr) {
    fmt::println("Node {{ key: {}, height: {} }}", node->Key(), node->Height());
    node = node->Next(LOWEST_LEVEL);
  }
}

/**
 * @brief Generate a random height. The height should be cappped at `MaxHeight`.
 * Note: we implement/simulate the geometric process to ensure platform independence.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::RandomHeight() -> size_t {
  // Branching factor (1 in 4 chance), see Pugh's paper.
  static constexpr unsigned int branching_factor = 4;
  // Start with the minimum height
  size_t height = 1;
  while (height < MaxHeight && (rng_() % branching_factor == 0)) {
    height++;
  }
  return height;
}

/**
 * @brief Gets the current node height.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::SkipNode::Height() const -> size_t {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  return links_.size();
}

/**
 * @brief Gets the next node by following the link at `level`.
 *
 * @param level index to the link.
 * @return std::shared_ptr<SkipNode> the next node, or `nullptr` if such node does not exist.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::SkipNode::Next(size_t level) const
    -> std::shared_ptr<SkipNode> {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  if (level >= links_.size()) {
    return nullptr;
  }
  return links_[level];
}

/**
 * @brief Set the `node` to be linked at `level`.
 *
 * @param level index to the link.
 */
SKIPLIST_TEMPLATE_ARGUMENTS void SkipList<K, Compare, MaxHeight, Seed>::SkipNode::SetNext(
    size_t level, const std::shared_ptr<SkipNode> &node) {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  if (level < links_.size()) {
    links_[level] = node;
  }
}

/** @brief Returns a reference to the key stored in the node. */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::SkipNode::Key() const -> const K & {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  return key_;
}

// Below are explicit instantiation of template classes.
template class SkipList<int>;
template class SkipList<std::string>;
template class SkipList<int, std::greater<>>;
template class SkipList<int, std::less<>, 8>;

}  // namespace bustub
